# f29-recovery — 비트코인 회복지수 (Phase 0 fixture 엔진)

- 지위: **Phase 0 (정적 골격 + fixture 엔진) + Phase 1 릴레이 스크립트 준비**
- production 공개: **HOLD** (스펙 §15 전건 + 외부 감리 비준 + Sky 결정 전까지)
- 영속 Shadow: **HOLD**
- 이 번들은 fixture로만 상태 전이를 검증한다. 외부 API·라이브 데이터 연결 없음.

## 정본 (RATIFIED / MACHINE_CANONICAL)

`contracts/` 에 원본 그대로 배치. 빌드·테스트 시작마다 SHA 재검사.

| 파일 | SHA-256 |
|---|---|
| RECOVERY_ENGINE_SPEC_v1.0_FINAL.md | `ac34c0ec…b5c67` |
| RECOVERY_USAGE_RIGHTS_v0.1.1.json | `7d2c43f8…a9e047` |
| RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md | `e5415943…4ea765` |

권리 정본 바이트가 바뀌면 기존 release approval은 자동 무효(`engine/canon.require_rights_sha`).

## 임계값 정책 (핵심)

- **운영 설정 `config/recovery_params.json` = 전부 `null`/`TBD`** (NORMATIVE_RUNTIME).
- **테스트 설정 `tests/fixtures/test_config.json` = 명시적 시험값** (NON_NORMATIVE).
- 연구 가설값(D3=3/D4=5/D5=10/W=2)은 운영 기본값으로 복사되지 않았다.
- 엔진이 `null` 임계값을 사용하려 하면 `ThresholdUnset` 예외 — 가설값 은닉 방지.

## 구조

```
config/     운영 설정 (임계값 null/TBD, source bindings, release policy=hold)
contracts/  정본 3종 (SHA 고정)
engine/     canon, rights, models, rights_graph, blockers, state_machine, ledger, templates, writers
ledger/     append-only 원장 (런타임 생성)
snapshots/  내부 shadow 출력 (런타임)
output/     공개 JSON — release gate approved 시에만 생성
probes/     Phase 1 probe 산출 (런타임, 원문 미저장)
scripts/    server_preflight.sh / phase1_tech_probe.sh / install_phase0.sh (릴레이용, 미실행)
tests/      test_recovery.py (53 케이스), demo_cycle.py, fixtures/
```

## 실행

```bash
python3 -m py_compile engine/*.py tests/*.py   # 정적 검사
python3 tests/test_recovery.py                  # 전수 테스트 (53)
python3 tests/demo_cycle.py                     # 1 사이클 시연
```

## 구현된 계약 (스펙 매핑)

- §3 정규화 관측치·pillar·source binding + 집계 규칙 (`models`, `rights_graph`)
- §4 실행 모드별 권리·재현성 등급 (`rights`, `ledger.assert_core_repro`)
- §6 blocker 3상태 (unknown≠inactive), spot_weakness anchor/run (`blockers`)
- §7·§8 B1~B5 candidate/ceiling/effective, 강등-후-ceiling, streak/breach/age (`state_machine`)
- §9 preliminary/canonical/fallback/revision append-only + late us_close replay (`ledger`)
- §11 shadow/public 물리 분리 + release gate HOLD 시 공개 미생성 (`writers`)
- §12 결정론적 템플릿 우선순위 + 전수 매핑 (미매칭 0·중복 0) (`templates`)
- §13 권리 그래프 transitive closure + 음성 테스트 (`rights_graph`)

## 이번 차수 HOLD / 미실행

- 서버 경로 확정·`/root/f29-recovery/` 배치 (preflight 릴레이 대기)
- Phase 1 TECH probe 실제 실행 (릴레이 대기)
- 실데이터 영속 수집 / Shadow 운영 / 공개 서비스 (전부 HOLD)
- cron·systemd·webroot·server.js·공개 라우트 변경 (금지)
