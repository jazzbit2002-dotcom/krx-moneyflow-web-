#!/usr/bin/env bash
# phase1_tech_probe.sh — Phase 1 TECH probe (읽기 전용).
#
# 지시서 Phase 1 + 관제 §7-B. Sky가 서버에서 실행. 이번 제출 범위에서는 실행하지 않는다(HOLD).
#
# 규칙:
#   - 외부 API는 읽기 전용 probe만. 응답 구조·필드·이력·available_at·revision·호출제한 확인.
#   - 실제 키는 환경변수로만 주입 (스크립트에 하드코딩 금지).
#   - 응답 원문을 공개 경로에 저장하지 않음. 결과는 TECH_PASS/TECH_FAIL만.
#   - usage_rights JSON 수정 금지. LICENSE_PASS 추정·출력 금지.
#   - TECH_PASS != LICENSE_PASS (스펙 §4.1).
#
# 필요 환경변수 (없으면 해당 소스 SKIP):
#   COINMETRICS_KEY, COINBASE_KEY, COINGECKO_PROBE_KEY, FRED_KEY
#   F29_INTERNAL_PRO_URL  (기본 http://127.0.0.1:3000/api/internal/pro)
set -u

RESULT_FILE="${1:-/tmp/recovery_tech_probe_result.json}"
TMPDIR_PROBE="$(mktemp -d)"
trap 'rm -rf "$TMPDIR_PROBE"' EXIT   # 원문은 임시 경로에서만, 종료 시 삭제

echo "======================================================================"
echo "F29-RECOVERY PHASE 1 TECH PROBE (read-only)  $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "결과 파일(TECH_PASS/FAIL만): $RESULT_FILE"
echo "======================================================================"

# 결과 누산 (JSON 조립)
declare -A VERDICT
declare -A DETAIL

probe_http() {
  # $1=이름 $2=url $3=헤더(선택)
  local name="$1" url="$2" hdr="${3:-}"
  local out="$TMPDIR_PROBE/$name.json"
  local code
  if [ -n "$hdr" ]; then
    code=$(curl -sS -o "$out" -w '%{http_code}' -H "$hdr" "$url" 2>/dev/null || echo "000")
  else
    code=$(curl -sS -o "$out" -w '%{http_code}' "$url" 2>/dev/null || echo "000")
  fi
  if [ "$code" = "200" ] && [ -s "$out" ]; then
    VERDICT[$name]="TECH_PASS"
    # 구조만 기록: top-level 키 목록·바이트 수 (원문 저장 안 함)
    local keys bytes
    bytes=$(wc -c < "$out")
    keys=$(python3 - "$out" <<'PY' 2>/dev/null || echo "unparseable"
import json,sys
try:
    d=json.load(open(sys.argv[1]))
    if isinstance(d,dict): print(",".join(list(d.keys())[:20]))
    elif isinstance(d,list): print(f"array[{len(d)}]")
    else: print(type(d).__name__)
except Exception as e:
    print("unparseable")
PY
)
    DETAIL[$name]="http=$code bytes=$bytes top_keys=$keys"
  else
    VERDICT[$name]="TECH_FAIL"
    DETAIL[$name]="http=$code (no data or non-200)"
  fi
}

echo
echo "=== 외부 공급원 probe (probe 권리=allowed 인 소스만) ==="

# Coin Metrics Community (probe allowed) — Realized Price 계열
if [ -n "${COINMETRICS_KEY:-}" ]; then
  probe_http "coinmetrics_community" \
    "https://community-api.coinmetrics.io/v4/timeseries/asset-metrics?assets=btc&metrics=CapRealUSD&page_size=1&api_key=${COINMETRICS_KEY}"
else
  VERDICT[coinmetrics_community]="SKIP"; DETAIL[coinmetrics_community]="COINMETRICS_KEY 미설정"
fi

# Coinbase market data (probe allowed) — BTC-USD trades/candles
if [ -n "${COINBASE_KEY:-}" ]; then
  probe_http "coinbase_market_data" \
    "https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=86400" \
    "User-Agent: f29-recovery-probe"
else
  VERDICT[coinbase_market_data]="SKIP"; DETAIL[coinbase_market_data]="COINBASE_KEY 미설정"
fi

# CoinGecko (probe key only) — breadth 후보
if [ -n "${COINGECKO_PROBE_KEY:-}" ]; then
  probe_http "coingecko" \
    "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&per_page=1&page=1" \
    "x-cg-demo-api-key: ${COINGECKO_PROBE_KEY}"
else
  VERDICT[coingecko]="SKIP"; DETAIL[coingecko]="COINGECKO_PROBE_KEY 미설정"
fi

# FRED (probe allowed, per-series 권리 감사 별도) — macro context
if [ -n "${FRED_KEY:-}" ]; then
  probe_http "fred" \
    "https://api.stlouisfed.org/fred/series?series_id=DFF&api_key=${FRED_KEY}&file_type=json"
else
  VERDICT[fred]="SKIP"; DETAIL[fred]="FRED_KEY 미설정"
fi

echo
echo "=== F29 내부 위험 엔진 인터페이스 (읽기 전용) ==="
# 스펙 §5-C / Phase 1: 실제 JSON 샘플·필드명·단위·시각·결측·이력만 확보.
# raw 지표는 저장하지 않고 필드 구조만 기록.
F29_URL="${F29_INTERNAL_PRO_URL:-http://127.0.0.1:3000/api/internal/pro}"
probe_http "f29_internal_risk_engine" "$F29_URL"
# derivatives_pressure 매핑 후보 필드 존재만 확인 (값 미저장)
if [ -f "$TMPDIR_PROBE/f29_internal_risk_engine.json" ]; then
  echo "  --- derivatives 관련 필드명 존재 확인 (값 미기록) ---"
  python3 - "$TMPDIR_PROBE/f29_internal_risk_engine.json" <<'PY' 2>/dev/null || echo "  parse 실패"
import json,sys
d=json.load(open(sys.argv[1]))
def walk(o,prefix=""):
    keys=[]
    if isinstance(o,dict):
        for k,v in o.items():
            keys.append(prefix+k)
            keys+=walk(v,prefix+k+".")
    return keys
allk=walk(d)
cand=[k for k in allk if any(t in k.lower() for t in
      ["deriv","funding","oi","liq","pressure","cvd","prem"])]
print("  후보 필드:", cand[:30] if cand else "없음 — adapter 매핑 재검토 필요")
PY
fi

echo
echo "======================================================================"
echo "TECH PROBE 판정 요약"
echo "======================================================================"
{
  echo "{"
  echo "  \"schema_version\": \"recovery_tech_probe.1\","
  echo "  \"probed_at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\","
  echo "  \"note\": \"TECH_PASS != LICENSE_PASS. usage_rights 미수정. 원문 미저장.\","
  echo "  \"results\": {"
  first=1
  for name in "${!VERDICT[@]}"; do
    [ $first -eq 0 ] && echo ","
    first=0
    printf '    "%s": {"verdict": "%s", "detail": "%s"}' \
      "$name" "${VERDICT[$name]}" "${DETAIL[$name]}"
  done
  echo
  echo "  }"
  echo "}"
} | tee "$RESULT_FILE"

echo
echo "결과는 TECH_PASS/TECH_FAIL/SKIP만 기록됨. LICENSE 판정은 별도 권리 정본 소관."
echo "usage_rights JSON 은 이 스크립트가 수정하지 않음."
