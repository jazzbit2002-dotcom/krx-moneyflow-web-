#!/usr/bin/env bash
# server_preflight.sh — 서버 사전점검 (읽기 전용).
#
# 지시서/관제 §7-A. Sky가 서버(root@vultr)에서 실행하고 출력을 회신한다.
# 이 스크립트는 어떤 파일도 생성·수정·삭제하지 않는다.
# webroot·cron·systemd·server.js 에 손대지 않는다.
#
# 목적:
#   1. /root/f29-recovery 존재·비어있음·충돌 여부
#   2. Python 버전 + 필요 표준 모듈
#   3. 정본 3종 SHA 재검사 (번들이 이미 서버에 있을 때)
#   4. 기존 위험 엔진 핵심 파일 SHA 스냅샷 (무변경 증거 baseline)
#
# 실행: bash server_preflight.sh
set -u  # set -e 미사용: 개별 점검 실패해도 전체 리포트 계속

echo "======================================================================"
echo "F29-RECOVERY SERVER PREFLIGHT (read-only)  $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "======================================================================"

echo
echo "=== [1] 작업 루트 충돌 점검: /root/f29-recovery ==="
TARGET=/root/f29-recovery
if [ -e "$TARGET" ]; then
  echo "STATUS: EXISTS"
  echo "  타입: $( [ -d "$TARGET" ] && echo directory || echo file )"
  if [ -d "$TARGET" ]; then
    N=$(find "$TARGET" -mindepth 1 2>/dev/null | wc -l)
    echo "  내부 항목 수: $N"
    if [ "$N" -eq 0 ]; then
      echo "  판정: EMPTY_DIR (배치 가능 후보)"
    else
      echo "  판정: NON_EMPTY — 충돌. 배치 중지, 내용 확인 필요."
      echo "  --- 상위 20개 항목 ---"
      find "$TARGET" -mindepth 1 -maxdepth 2 2>/dev/null | head -20
    fi
  fi
else
  echo "STATUS: ABSENT (신규 생성 가능 후보)"
fi

echo
echo "=== [2] Python 환경 ==="
if command -v python3 >/dev/null 2>&1; then
  python3 --version
  echo -n "  표준 모듈 확인: "
  python3 - <<'PY'
mods = ["json","hashlib","dataclasses","tempfile","unittest","os","sys"]
missing = []
for m in mods:
    try:
        __import__(m)
    except Exception as e:
        missing.append(f"{m}({e})")
print("ALL OK" if not missing else f"MISSING: {missing}")
PY
else
  echo "  python3 없음 — Phase 0 실행 불가"
fi

echo
echo "=== [3] 정본 3종 SHA 재검사 (contracts/ 가 서버에 있을 때) ==="
CDIR="$TARGET/contracts"
declare -A EXPECT=(
  ["RECOVERY_ENGINE_SPEC_v1.0_FINAL.md"]="ac34c0ec5bc40043bec9e5ffadbeb2891632055c706132d43c83d946528b5c67"
  ["RECOVERY_USAGE_RIGHTS_v0.1.1.json"]="7d2c43f849a51d129d16c731f711ad86e06cdc84875ec240e7825f8acfa9e047"
  ["RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md"]="e5415943fe04f7d3fba21a1698c834e09177637130a3da98cf326069d34ea765"
)
if [ -d "$CDIR" ]; then
  for f in "${!EXPECT[@]}"; do
    if [ -f "$CDIR/$f" ]; then
      ACT=$(sha256sum "$CDIR/$f" | cut -d' ' -f1)
      if [ "$ACT" = "${EXPECT[$f]}" ]; then
        echo "  PASS  $f"
      else
        echo "  FAIL  $f"
        echo "        기대 ${EXPECT[$f]}"
        echo "        실측 $ACT"
      fi
    else
      echo "  ABSENT $f"
    fi
  done
else
  echo "  contracts/ 미배치 — install 전이므로 정상 (배치 후 재점검)"
fi

echo
echo "=== [4] 기존 위험 엔진 무변경 baseline SHA (읽기 전용 스냅샷) ==="
echo "  (이 값을 Phase 0 전후로 대조 — 회복 작업이 위험 엔진을 건드리지 않았음을 증명)"
for f in /root/f29/server.js /root/f29/public/pro.html /root/f29/public/index.html; do
  if [ -f "$f" ]; then
    echo "  $(sha256sum "$f")"
  else
    echo "  ABSENT $f"
  fi
done

echo
echo "=== [5] webroot/cron/systemd 무변경 확인 (읽기 전용 조회만) ==="
echo "  --- /recovery 공개 라우트 부재 확인 (nginx) ---"
grep -rn "recovery" /etc/nginx/sites-enabled/ 2>/dev/null || echo "  nginx에 recovery 라우트 없음 (정상)"
echo "  --- cron에 recovery 항목 부재 확인 ---"
crontab -l 2>/dev/null | grep -i recovery || echo "  cron에 recovery 없음 (정상)"

echo
echo "======================================================================"
echo "PREFLIGHT 완료. 위 판정을 관제/Opus 세션에 회신하십시오."
echo "  - [1] EMPTY_DIR 또는 ABSENT 여야 install 진행 가능"
echo "  - [4] baseline SHA는 Phase 0 종료 후 재측정해 동일함을 증명"
echo "======================================================================"
