#!/usr/bin/env bash
# install_phase0.sh — 로컬 Phase 0 번들을 /root/f29-recovery/ 에 배치.
#
# 지시서/관제 §8. 자동 실행 금지. preflight PASS 후 사용자가 명시적으로만 실행.
# webroot·route·cron·systemd 연결 기능을 포함하지 않는다 (순수 파일 배치 + SHA 검증).
#
# 실행 전제:
#   - server_preflight.sh 결과가 [1] EMPTY_DIR 또는 ABSENT
#   - 이 스크립트와 번들이 같은 디렉터리(예: 압축 해제된 f29-recovery/) 안에 있음
#
# 사용법:
#   bash install_phase0.sh /path/to/unpacked/f29-recovery
set -eu

SRC="${1:-}"
TARGET=/root/f29-recovery

if [ -z "$SRC" ] || [ ! -d "$SRC" ]; then
  echo "사용법: bash install_phase0.sh <압축해제된_f29-recovery_경로>"
  exit 2
fi

echo "=== [사전] 대상 충돌 재확인 ==="
if [ -e "$TARGET" ]; then
  if [ -d "$TARGET" ] && [ -z "$(find "$TARGET" -mindepth 1 2>/dev/null)" ]; then
    echo "  $TARGET 존재하나 EMPTY — 진행 가능"
  else
    echo "  중지: $TARGET 이 비어있지 않음. preflight 재확인 필요."
    exit 1
  fi
fi

echo "=== [1] 정본 SHA 사전 검증 (SRC/contracts) ==="
declare -A EXPECT=(
  ["RECOVERY_ENGINE_SPEC_v1.0_FINAL.md"]="ac34c0ec5bc40043bec9e5ffadbeb2891632055c706132d43c83d946528b5c67"
  ["RECOVERY_USAGE_RIGHTS_v0.1.1.json"]="7d2c43f849a51d129d16c731f711ad86e06cdc84875ec240e7825f8acfa9e047"
  ["RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md"]="e5415943fe04f7d3fba21a1698c834e09177637130a3da98cf326069d34ea765"
)
for f in "${!EXPECT[@]}"; do
  ACT=$(sha256sum "$SRC/contracts/$f" | cut -d' ' -f1)
  if [ "$ACT" != "${EXPECT[$f]}" ]; then
    echo "  FAIL 정본 SHA 불일치: $f — 배치 중지 (자동 보정 금지)"
    exit 1
  fi
  echo "  PASS $f"
done

echo "=== [2] 파일 배치 (rsync 복사, webroot/route/cron/systemd 무연결) ==="
mkdir -p "$TARGET"
cp -a "$SRC/." "$TARGET/"

echo "=== [3] 배치 후 정본 SHA 재검증 ==="
for f in "${!EXPECT[@]}"; do
  ACT=$(sha256sum "$TARGET/contracts/$f" | cut -d' ' -f1)
  [ "$ACT" = "${EXPECT[$f]}" ] && echo "  PASS $f" || { echo "  FAIL $f"; exit 1; }
done

echo "=== [4] py_compile + 테스트 (배치본에서 재실행) ==="
cd "$TARGET"
python3 -m py_compile engine/*.py tests/*.py && echo "  py_compile OK"
python3 tests/test_recovery.py >/tmp/recovery_test_after_install.log 2>&1 \
  && echo "  테스트 PASS (로그 /tmp/recovery_test_after_install.log)" \
  || { echo "  테스트 FAIL — 로그 확인"; tail -20 /tmp/recovery_test_after_install.log; exit 1; }

echo
echo "=== 배치 완료 ==="
echo "  위치: $TARGET"
echo "  주의: 이 스크립트는 공개 라우트·cron·systemd 를 연결하지 않았다."
echo "  Shadow/공개는 별도 게이트·비준 전까지 HOLD."
