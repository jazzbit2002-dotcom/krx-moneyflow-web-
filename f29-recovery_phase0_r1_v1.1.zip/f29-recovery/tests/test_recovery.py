"""
test_recovery.py — Phase 0 fixture 전수 테스트.

지시서 §필수 테스트 + 관제 판정 §6 전건. 순수 표준 라이브러리(unittest).
전이 기대값/실제값을 수집해 표로 출력한다.
"""

import json
import os
import sys
import tempfile
import unittest

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from engine import canon
from engine.canon import CanonMismatch
from engine.rights import RightsMatrix, RightsError
from engine.models import (
    Pillar, SourceBinding, RecoveryConfig, ThresholdUnset, load_source_bindings,
)
from engine import rights_graph as RG
from engine.rights_graph import DependencyGraph, GraphError
from engine import blockers as BLK
from engine.blockers import BlockerInputs
from engine import state_machine as SM
from engine.state_machine import PersistentState, PillarSnapshot
from engine import ledger as LG
from engine.ledger import Ledger, LedgerRecord, LedgerError
from engine import templates as TPL
from engine import writers as WR


# 전이 기록 수집 (fixture 전이표용)
TRANSITIONS = []


def record_transition(name, expected, actual):
    TRANSITIONS.append((name, expected, actual, "PASS" if expected == actual else "FAIL"))


def load_test_cfg():
    p = os.path.join(BASE, "tests", "fixtures", "test_config.json")
    with open(p) as f:
        d = json.load(f)
    return RecoveryConfig.from_dict(d["thresholds"])


def mk_snapshot(**kw):
    base = dict(
        a_state="unconfirmed", a_fresh="fresh",
        b_state="unconfirmed", b_fresh="fresh", b_maturity="validated",
        e_state="unconfirmed", e_fresh="fresh",
        derivatives_pressure="normal", e_reconfirm_ok=False,
    )
    base.update(kw)
    return PillarSnapshot(**base)


def mk_blockers(sb="inactive", dl="inactive", do="inactive"):
    return {"structure_break": sb, "derivatives_led": dl, "derivatives_overheated": do}


def mk_inputs(**kw):
    base = dict(
        spot_state="unconfirmed", spot_freshness="fresh", spot_maturity="validated",
        structure_state="unconfirmed", structure_freshness="fresh",
        derivatives_pressure="normal",
    )
    base.update(kw)
    return BlockerInputs(**base)


class TestCanon(unittest.TestCase):
    def test_contracts_match(self):
        result = canon.verify_contracts(BASE)
        self.assertEqual(len(result), 3)

    def test_rights_sha_change_invalidates(self):
        # 정본 SHA 변경 → CanonMismatch (릴리스 approval 무효)
        with self.assertRaises(CanonMismatch):
            canon.require_rights_sha("deadbeef" * 8)


class TestRights(unittest.TestCase):
    def setUp(self):
        self.rights = RightsMatrix.load(BASE)

    def test_enum_validation(self):
        self.assertEqual(self.rights.data["enums"]["rights"],
                         ["allowed", "pending", "blocked"])

    def test_pointer_resolves(self):
        s = self.rights.resolve_pointer(
            "RECOVERY_USAGE_RIGHTS_v0.1.1.json#/sources/coinbase_market_data")
        self.assertEqual(s["probe"], "allowed")

    def test_pointer_dangling_fails(self):
        with self.assertRaises(RightsError):
            self.rights.resolve_pointer(
                "RECOVERY_USAGE_RIGHTS_v0.1.1.json#/sources/nonexistent")

    def test_pending_not_allowed(self):
        # coinmetrics internal_shadow = pending → auditable_shadow 미허용
        self.assertFalse(self.rights.mode_allowed("coinmetrics_community", "internal_shadow"))
        # coinbase internal_shadow = allowed
        self.assertTrue(self.rights.mode_allowed("coinbase_market_data", "internal_shadow"))

    def test_unknown_source_fails(self):
        with self.assertRaises(RightsError):
            self.rights.source("no_such_source")


class TestBindingAggregation(unittest.TestCase):
    def _pillar(self, req_tech="pass", opt_tech=None):
        binds = [SourceBinding("s_req", "d", "required", req_tech,
                               "RECOVERY_USAGE_RIGHTS_v0.1.1.json#/sources/coinbase_market_data",
                               "decision_replay")]
        if opt_tech is not None:
            binds.append(SourceBinding("s_opt", "d2", "optional", opt_tech,
                                       "RECOVERY_USAGE_RIGHTS_v0.1.1.json#/sources/fred",
                                       "provenance_only"))
        return Pillar("A", "structure", source_bindings=binds)

    def test_required_missing_blocks_pillar(self):
        r = RG.evaluate_binding_availability(self._pillar(req_tech="fail"))
        record_transition("required binding fail -> pillar unusable",
                          (False, "missing"), (r["usable"], r["freshness_override"]))
        self.assertFalse(r["usable"])
        self.assertEqual(r["freshness_override"], "missing")

    def test_optional_missing_degrades(self):
        r = RG.evaluate_binding_availability(self._pillar(req_tech="pass", opt_tech="fail"))
        record_transition("optional binding fail -> degraded",
                          (True, True), (r["usable"], r["degraded"]))
        self.assertTrue(r["usable"])
        self.assertTrue(r["degraded"])


class TestRightsGraph(unittest.TestCase):
    def setUp(self):
        self.rights = RightsMatrix.load(BASE)
        self.graph = DependencyGraph()
        sb = load_source_bindings(BASE)["pillars"]
        self.pillars = []
        for name, pdef in sb.items():
            p = Pillar(
                axis=pdef["axis"], name=name, role=pdef.get("role", ""),
                maturity=pdef.get("maturity", "validated"),
                source_bindings=[SourceBinding.from_dict(b) for b in pdef["bindings"]],
                dependencies=list(pdef.get("dependencies", [])),
            )
            self.pillars.append(p)
            self.graph.add_pillar(p)

    def test_all_refs_resolve(self):
        RG.resolve_all_refs(self.pillars, self.rights)  # 실패 시 raise

    def test_no_cycle(self):
        self.graph.validate_structure()

    def test_dangling_dependency_fails(self):
        g = DependencyGraph()
        p = Pillar("A", "x", dependencies=["ghost"])
        g.add_pillar(p)
        with self.assertRaises(GraphError):
            g.validate_structure()

    def test_cycle_fails(self):
        g = DependencyGraph()
        g.add_pillar(Pillar("A", "x", dependencies=["y"]))
        g.add_pillar(Pillar("B", "y", dependencies=["x"]))
        with self.assertRaises(GraphError):
            g.validate_structure()

    def test_public_closure_blocked_by_pending(self):
        # spot_demand(coinbase public_derived=blocked) 기여 → 공개 차단
        res = RG.public_closure_blocked(["spot_demand"], self.graph, self.rights)
        record_transition("closure with pending/blocked public_derived -> public blocked",
                          True, res["blocked"])
        self.assertTrue(res["blocked"])
        self.assertIn("coinbase_market_data", res["blocking_sources"])

    def test_blocker_upstream_included(self):
        # derivatives_quality(C) depends on spot_demand → closure에 spot 소스 포함
        srcs = self.graph.transitive_sources(["derivatives_quality"])
        self.assertIn("f29_internal_risk_engine", srcs)
        self.assertIn("coinbase_market_data", srcs)  # dependency 통해

    def test_optional_macro_excluded_when_unused(self):
        # macro(fred, optional) 미사용 → 공개 closure에서 제외
        res = RG.public_closure_blocked(["macro"], self.graph, self.rights,
                                        used_optional_sources=set())
        self.assertNotIn("fred", res["closure"])

    def test_optional_macro_included_when_used(self):
        res = RG.public_closure_blocked(["macro"], self.graph, self.rights,
                                        used_optional_sources={"fred"})
        self.assertIn("fred", res["closure"])


class TestBlockers(unittest.TestCase):
    def setUp(self):
        self.cfg = load_test_cfg()

    def test_derivatives_led_active(self):
        inp = mk_inputs(derivatives_pressure="strong", spot_state="partial")
        r = BLK.eval_derivatives_led(inp)
        record_transition("deriv strong + spot!=confirmed + fresh -> derivatives_led active",
                          "active", r)
        self.assertEqual(r, "active")

    def test_derivatives_led_unknown_on_stale(self):
        inp = mk_inputs(derivatives_pressure="strong", spot_freshness="stale")
        self.assertEqual(BLK.eval_derivatives_led(inp), "unknown")

    def test_derivatives_overheated_active(self):
        inp = mk_inputs(derivatives_pressure="overheated", spot_state="confirmed")
        self.assertEqual(BLK.eval_derivatives_overheated(inp), "active")

    def test_blocker_unknown_not_inactive(self):
        # deriv unknown → blocker unknown (inactive 아님)
        inp = mk_inputs(derivatives_pressure="unknown")
        record_transition("deriv pressure unknown -> derivatives_led unknown",
                          "unknown", BLK.eval_derivatives_led(inp))
        self.assertEqual(BLK.eval_derivatives_led(inp), "unknown")

    def test_spot_weakness_partial_once_inactive(self):
        # confirmed anchor + partial 1회 (< W=2) → inactive
        r = BLK.eval_spot_weakness("partial", "fresh", "validated",
                                   confirmed_anchor="2026-07-14.us_close",
                                   weakness_streak=1, history_sufficient=True, cfg=self.cfg)
        record_transition("confirmed anchor + partial 1회 -> spot_weakness inactive",
                          "inactive", r)
        self.assertEqual(r, "inactive")

    def test_spot_weakness_partial_W_active(self):
        # confirmed anchor + partial W=2회 → active
        r = BLK.eval_spot_weakness("partial", "fresh", "validated",
                                   confirmed_anchor="2026-07-14.us_close",
                                   weakness_streak=2, history_sufficient=True, cfg=self.cfg)
        record_transition("confirmed anchor + partial W회 -> spot_weakness active",
                          "active", r)
        self.assertEqual(r, "active")

    def test_spot_weakness_provisional_unknown(self):
        # provisional B → spot_weakness unknown (structure_break 입력 불가)
        r = BLK.eval_spot_weakness("partial", "fresh", "provisional",
                                   confirmed_anchor="2026-07-14.us_close",
                                   weakness_streak=5, history_sufficient=True, cfg=self.cfg)
        record_transition("provisional B -> spot_weakness unknown",
                          "unknown", r)
        self.assertEqual(r, "unknown")

    def test_structure_break_active(self):
        inp = mk_inputs(structure_state="adverse", derivatives_pressure="strong")
        r = BLK.eval_structure_break(inp, spot_weakness_state="active")
        self.assertEqual(r, "active")

    def test_structure_break_unknown_when_spotweak_unknown(self):
        inp = mk_inputs(structure_state="adverse", derivatives_pressure="strong")
        r = BLK.eval_structure_break(inp, spot_weakness_state="unknown")
        self.assertEqual(r, "unknown")


class TestStateMachine(unittest.TestCase):
    def setUp(self):
        self.cfg = load_test_cfg()

    def _eval(self, prev, snap, blockers, spot_weakness=None, preliminary=False):
        if spot_weakness is None:
            spot_weakness = {"state": "inactive", "confirmed_anchor": None, "weakness_streak": 0}
        return SM.evaluate(prev, snap, blockers, spot_weakness, self.cfg, preliminary)

    def test_b1_plus_A_confirmed_deriv_led_to_B2(self):
        # B1 + A confirmed + derivatives_led active → B2
        prev = PersistentState(effective_stage="B1")
        snap = mk_snapshot(a_state="confirmed", b_state="partial",
                           derivatives_pressure="strong")
        blk = mk_blockers(dl="active")
        r = self._eval(prev, snap, blk)
        record_transition("B1 + A confirmed + derivatives_led active -> B2",
                          "B2", r.effective_stage)
        self.assertEqual(r.effective_stage, "B2")

    def test_b4_downgrade_deriv_led_to_B2(self):
        # B4 + 일반 강등 + derivatives_led active → B2
        # 강등: B4 유지 predicate false + breach W회. deriv_led active → ceiling B2.
        prev = PersistentState(effective_stage="B4", maintenance_breach_streak=1)
        # B4 유지 실패(예: b_state != confirmed), fresh, deriv strong → spot!=confirmed
        snap = mk_snapshot(a_state="confirmed", b_state="partial", b_maturity="validated",
                           e_state="confirmed", derivatives_pressure="strong")
        blk = mk_blockers(dl="active")
        r = self._eval(prev, snap, blk)
        record_transition("B4 + 일반 강등 + derivatives_led active -> B2",
                          "B2", r.effective_stage)
        self.assertEqual(r.effective_stage, "B2")
        self.assertTrue(r.downgraded)

    def test_b3_downgrade_overheated_to_B2(self):
        # B3 + 일반 강등 + derivatives_overheated active → B2
        # 강등 target B2, overheated ceiling B3 → min(B2,B3)=B2
        prev = PersistentState(effective_stage="B3", maintenance_breach_streak=1)
        snap = mk_snapshot(a_state="confirmed", b_state="confirmed", b_maturity="validated",
                           derivatives_pressure="overheated")
        # B3 유지 predicate 훼손을 위해 a_state를 partial로
        snap.a_state = "partial"
        blk = mk_blockers(do="active")
        r = self._eval(prev, snap, blk)
        record_transition("B3 + 일반 강등 + derivatives_overheated active -> B2",
                          "B2", r.effective_stage)
        self.assertEqual(r.effective_stage, "B2")
        self.assertTrue(r.downgraded)

    def test_confirmed_downgrade_executes(self):
        # (구 misnamed test_blocker_unknown_confirmed_downgrade_executes 정정 —
        #  이 케이스는 blocker 전부 inactive인 일반 강등 실행 검증)
        prev = PersistentState(effective_stage="B3", maintenance_breach_streak=1)
        snap = mk_snapshot(a_state="partial", b_state="confirmed", b_maturity="validated",
                           derivatives_pressure="normal")
        blk = mk_blockers()  # 전부 inactive
        r = self._eval(prev, snap, blk)
        record_transition("확인된 강등(blocker 전부 inactive) -> 강등 실행",
                          True, r.downgraded)
        self.assertTrue(r.downgraded)
        self.assertEqual(r.effective_stage, "B2")

    def test_r1_blocker_unknown_confirmed_downgrade_executes(self):
        # R1-FIX2 회귀: 무관 blocker unknown + fresh 입력으로 W회 확인된 강등 → 실행
        # B3 유지 predicate는 pillar만 참조 — derivatives_led unknown은 무관.
        prev = PersistentState(effective_stage="B3", maintenance_breach_streak=1)
        snap = mk_snapshot(a_state="partial", b_state="confirmed", b_maturity="validated",
                           derivatives_pressure="unknown")
        blk = mk_blockers(dl="unknown")  # 실제 unknown 포함
        r = self._eval(prev, snap, blk)
        record_transition("R1: blocker unknown + fresh W회 확인 강등 -> 강등 실행 (B3->B2)",
                          (True, "B2"), (r.downgraded, r.effective_stage))
        self.assertTrue(r.downgraded)
        self.assertEqual(r.effective_stage, "B2")

    def test_blocker_unknown_no_downgrade_freezes(self):
        # blocker unknown + 강등 없음 → 상향 금지·동결
        prev = PersistentState(effective_stage="B2", maintenance_breach_streak=0)
        # A confirmed로 B2 유지, deriv unknown → 상향 금지
        snap = mk_snapshot(a_state="confirmed", b_state="confirmed", b_maturity="validated",
                           derivatives_pressure="unknown")
        blk = mk_blockers(dl="unknown")
        r = self._eval(prev, snap, blk)
        record_transition("blocker unknown + 강등 없음 -> 상향 금지·동결",
                          ("B2", "blocker_unknown_no_promotion"),
                          (r.effective_stage, r.frozen_reason))
        self.assertEqual(r.effective_stage, "B2")
        self.assertEqual(r.frozen_reason, "blocker_unknown_no_promotion")

    def test_provisional_B_no_B3(self):
        # provisional B축 → B3 금지
        prev = PersistentState(effective_stage="B2")
        snap = mk_snapshot(a_state="confirmed", b_state="confirmed", b_maturity="provisional")
        blk = mk_blockers()
        # streak 충분히 줘도 provisional이면 B3 자격 predicate false
        prev.promotion_streaks = {"B3": 99, "B4": 0, "B5": 0}
        r = self._eval(prev, snap, blk)
        record_transition("provisional B -> B3 금지 (최대 B2)",
                          "B2", r.effective_stage)
        self.assertEqual(r.effective_stage, "B2")

    def test_structure_break_forces_B1(self):
        # structure_break active → B1, streak 0, age 1
        prev = PersistentState(effective_stage="B4",
                               promotion_streaks={"B3": 5, "B4": 5, "B5": 0},
                               effective_stage_age_days=10)
        snap = mk_snapshot(a_state="adverse", derivatives_pressure="strong")
        blk = mk_blockers(sb="active")
        r = self._eval(prev, snap, blk)
        record_transition("structure_break active -> B1, streak 0, age 1",
                          ("B1", {"B3": 0, "B4": 0, "B5": 0}, 1),
                          (r.effective_stage, r.promotion_streaks, r.effective_stage_age_days))
        self.assertEqual(r.effective_stage, "B1")
        self.assertEqual(r.promotion_streaks, {"B3": 0, "B4": 0, "B5": 0})
        self.assertEqual(r.effective_stage_age_days, 1)

    def test_active_blocker_allows_up_to_ceiling(self):
        # active blocker가 자기 ceiling까지 상승 허용
        # derivatives_led active, A confirmed → candidate B2까지 허용(ceiling B2)
        prev = PersistentState(effective_stage="B1")
        snap = mk_snapshot(a_state="confirmed", b_state="partial",
                           derivatives_pressure="strong")
        blk = mk_blockers(dl="active")
        r = self._eval(prev, snap, blk)
        self.assertEqual(r.effective_stage, "B2")  # ceiling까지 상승

    def test_preliminary_no_persistent_change(self):
        # preliminary 평가가 영속 카운터를 변경하지 않음
        prev = PersistentState(effective_stage="B2",
                               promotion_streaks={"B3": 2, "B4": 0, "B5": 0},
                               effective_stage_age_days=5)
        snap = mk_snapshot(a_state="confirmed", b_state="confirmed", b_maturity="validated")
        blk = mk_blockers()
        r = self._eval(prev, snap, blk, preliminary=True)
        record_transition("preliminary -> 영속 streak/age 불변",
                          ({"B3": 2, "B4": 0, "B5": 0}, 5),
                          (r.promotion_streaks, r.effective_stage_age_days))
        self.assertEqual(r.promotion_streaks, {"B3": 2, "B4": 0, "B5": 0})
        self.assertEqual(r.effective_stage_age_days, 5)


class TestLedger(unittest.TestCase):
    def test_canonical_once_per_market_date(self):
        led = Ledger()
        r1 = led.append(LedgerRecord("2026-07-16.us_close", "2026-07-16", "canonical",
                                     True, {"effective_stage": "B2"}))
        self.assertTrue(r1.counted)
        # 동일 market_date 두 번째 canonical (다른 id) → 가산 안 함
        r2 = led.append(LedgerRecord("2026-07-16.us_close.r1", "2026-07-16", "revision",
                                     True, {"effective_stage": "B3"}))
        record_transition("canonical market_date당 1회 가산",
                          (True, False), (r1.counted, r2.counted))
        self.assertTrue(r1.counted)
        self.assertFalse(r2.counted)

    def test_preliminary_not_counted(self):
        led = Ledger()
        r = led.append(LedgerRecord("2026-07-16.daily", "2026-07-16", "preliminary",
                                    False, {"effective_stage": "B2"}))
        record_transition("preliminary -> counted false", False, r.counted)
        self.assertFalse(r.counted)

    def test_idempotent_rerun(self):
        led = Ledger()
        led.append(LedgerRecord("2026-07-16.us_close", "2026-07-16", "canonical",
                                True, {"effective_stage": "B2"}))
        n_before = len(led.records)
        # 재실행 — 덮어쓰되 카운터 재가산 없음
        led.append(LedgerRecord("2026-07-16.us_close", "2026-07-16", "canonical",
                                True, {"effective_stage": "B3"}))
        self.assertEqual(len(led.records), n_before)  # append-only, 중복 레코드 없음
        self.assertEqual(led.get("2026-07-16.us_close").payload["effective_stage"], "B3")

    def test_late_us_close_replay_changes_canonical(self):
        # late us_close replay 가능 & 결과 상이 → r1 canonical revision
        led = Ledger()
        led.append(LedgerRecord("2026-07-16.daily_fallback", "2026-07-16", "fallback",
                                True, {"effective_stage": "B2"}))
        rec = led.apply_late_us_close("2026-07-16", replay_possible=True,
                                      replayed_payload={"effective_stage": "B3"},
                                      fallback_eid="2026-07-16.daily_fallback")
        record_transition("late us_close replay 가능+상이 -> r1 canonical revision",
                          ("2026-07-16.us_close.r1", True),
                          (led.canonical_index["2026-07-16"], rec.is_canonical))
        self.assertEqual(led.canonical_index["2026-07-16"], "2026-07-16.us_close.r1")
        # fallback 레코드 보존
        self.assertIsNotNone(led.get("2026-07-16.daily_fallback"))

    def test_late_us_close_replay_impossible(self):
        # late us_close replay 불가 → late_data_unapplied, fallback 유지
        led = Ledger()
        led.append(LedgerRecord("2026-07-16.daily_fallback", "2026-07-16", "fallback",
                                True, {"effective_stage": "B2"}))
        rec = led.apply_late_us_close("2026-07-16", replay_possible=False,
                                      replayed_payload=None,
                                      fallback_eid="2026-07-16.daily_fallback")
        record_transition("late us_close replay 불가 -> late_data_unapplied",
                          ("2026-07-16.daily_fallback", True),
                          (led.canonical_index["2026-07-16"],
                           rec.payload.get("late_data_unapplied")))
        self.assertEqual(led.canonical_index["2026-07-16"], "2026-07-16.daily_fallback")
        self.assertTrue(rec.payload.get("late_data_unapplied"))

    def test_provenance_only_core_forbidden(self):
        # provenance_only 핵심축 사용 금지
        with self.assertRaises(LedgerError):
            LG.assert_core_repro("provenance_only")
        # decision_replay 이상은 통과
        LG.assert_core_repro("decision_replay")
        LG.assert_core_repro("full")


class TestTemplates(unittest.TestCase):
    def test_priority_data_delayed_wins(self):
        t = TPL.select_template("data_delayed", mk_blockers(sb="active"), "B4")
        self.assertEqual(t["template_id"], "REC-DELAYED-01")

    def test_priority_structure_break(self):
        t = TPL.select_template("ok", mk_blockers(sb="active", dl="active"), "B1")
        self.assertEqual(t["template_id"], "REC-STRUCTBREAK-01")

    def test_priority_deriv_led_over_overheated(self):
        t = TPL.select_template("ok", mk_blockers(dl="active", do="active"), "B2")
        self.assertEqual(t["template_id"], "REC-B2-DERIV-LED-01")

    def test_stage_fallthrough(self):
        for stg in ("B1", "B2", "B3", "B4", "B5"):
            t = TPL.select_template("ok", mk_blockers(), stg)
            self.assertTrue(t["template_id"].startswith("REC-B"))

    def test_no_forbidden_terms(self):
        violations = TPL.check_forbidden_terms()
        record_transition("템플릿 금칙어 검사", [], violations)
        self.assertEqual(violations, [])

    def test_exhaustive_mapping_no_gap_no_dup(self):
        # 도달 가능한 모든 조합 열거 → 정확히 1개 템플릿, 미매칭 0·중복 0
        statuses = ["ok", "data_delayed"]
        sb_states = ["active", "inactive", "unknown"]
        dl_states = ["active", "inactive", "unknown"]
        do_states = ["active", "inactive", "unknown"]
        stages = ["B1", "B2", "B3", "B4", "B5"]
        total = 0
        matched = 0
        for status in statuses:
            for sb in sb_states:
                for dl in dl_states:
                    for do in do_states:
                        for stg in stages:
                            total += 1
                            blk = {"structure_break": sb,
                                   "derivatives_led": dl,
                                   "derivatives_overheated": do}
                            t = TPL.select_template(status, blk, stg)
                            # 정확히 하나 — select_template은 단일 반환/예외
                            self.assertIn("template_id", t)
                            matched += 1
        record_transition("템플릿 전수 매핑 (미매칭 0·중복 0)",
                          (total, total), (total, matched))
        self.assertEqual(total, matched)


class TestWriters(unittest.TestCase):
    def test_public_not_created_on_hold(self):
        # release HOLD 시 공개 JSON 미생성
        with tempfile.TemporaryDirectory() as d:
            gate = WR.build_release_gate("hold", "usage_rights_pending",
                                         "2026-07-16T00:00:00Z", canon.RIGHTS_SHA)
            path = WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                               "ok", mk_blockers())
            files = os.listdir(d)
            record_transition("release HOLD -> 공개 파일 미생성",
                              (None, []), (path, files))
            self.assertIsNone(path)
            self.assertEqual(files, [])

    def test_public_created_on_approved(self):
        with tempfile.TemporaryDirectory() as d:
            gate = WR.build_release_gate("approved", "approved",
                                         "2026-07-16T00:00:00Z", canon.RIGHTS_SHA,
                                         rights_graph_verdict="pass")
            path = WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                               "ok", mk_blockers())
            self.assertIsNotNone(path)
            self.assertTrue(os.path.exists(path))
            with open(path) as f:
                body = json.load(f)
            # 공개 금지 필드 부재 확인
            for forbidden in ("candidate_stage", "pillars", "blockers", "ceiling_sources"):
                self.assertNotIn(forbidden, body)

    def test_approved_but_rights_sha_changed_blocks(self):
        # rights 정본 SHA 변경 시 approval 무효 → 생성 차단
        with tempfile.TemporaryDirectory() as d:
            gate = WR.build_release_gate("approved", "approved",
                                         "2026-07-16T00:00:00Z", "bad" * 21 + "x",
                                         rights_graph_verdict="pass")
            with self.assertRaises(CanonMismatch):
                WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                            "ok", mk_blockers())

    def test_shadow_always_writable(self):
        with tempfile.TemporaryDirectory() as d:
            path = WR.write_shadow_latest(d, {"market_date": "2026-07-16",
                                              "candidate_stage": "B3",
                                              "effective_stage": "B2"})
            self.assertTrue(os.path.exists(path))


class TestThresholdSafety(unittest.TestCase):
    def test_runtime_config_all_null(self):
        # 운영 설정은 전부 null — 상태기계가 임계값 요구 시 ThresholdUnset
        rt = RecoveryConfig.from_runtime(BASE)
        self.assertIsNone(rt.D3)
        self.assertIsNone(rt.W_downgrade)
        with self.assertRaises(ThresholdUnset):
            rt.require("D3")

    def test_hypothesis_values_not_in_runtime(self):
        # 연구 가설값(3/5/10/2)이 운영 설정에 없음
        rt = RecoveryConfig.from_runtime(BASE)
        for v in (rt.D3, rt.D4, rt.D5, rt.W_downgrade, rt.W_spot_weakness):
            self.assertIsNone(v)


class TestR1Regressions(unittest.TestCase):
    """PHASE0-R1 차단 4건 회귀 테스트 — 감리 실측 결함 케이스 그대로 재현."""

    def setUp(self):
        self.cfg = load_test_cfg()

    def _eval(self, prev, snap, blockers, preliminary=False):
        sw = {"state": "inactive", "confirmed_anchor": None, "weakness_streak": 0}
        return SM.evaluate(prev, snap, blockers, sw, self.cfg, preliminary)

    # ── 차단 1: 강등 W회 미충족 시 하강 금지 ─────────────────────────
    def test_r1_first_breach_holds_stage(self):
        # 감리 실측 케이스: B3, W=2, breach 0, A partial, B confirmed, blocker 전부 inactive
        # 기대: B3 유지, breach 0→1, downgraded False (구 구현은 B2로 즉시 하강했음)
        prev = PersistentState(effective_stage="B3", maintenance_breach_streak=0)
        snap = mk_snapshot(a_state="partial", b_state="confirmed", b_maturity="validated")
        r = self._eval(prev, snap, mk_blockers())
        record_transition("R1: 첫 훼손 -> B3 유지, breach 1, 강등 없음",
                          ("B3", 1, False),
                          (r.effective_stage, r.maintenance_breach_streak, r.downgraded))
        self.assertEqual(r.effective_stage, "B3")
        self.assertEqual(r.maintenance_breach_streak, 1)
        self.assertFalse(r.downgraded)

    def test_r1_second_breach_downgrades(self):
        # 두 번째 연속 훼손(W=2 도달)에서만 B2로 강등
        prev = PersistentState(effective_stage="B3", maintenance_breach_streak=1)
        snap = mk_snapshot(a_state="partial", b_state="confirmed", b_maturity="validated")
        r = self._eval(prev, snap, mk_blockers())
        record_transition("R1: 2연속 훼손(W도달) -> B2 강등",
                          ("B2", True), (r.effective_stage, r.downgraded))
        self.assertEqual(r.effective_stage, "B2")
        self.assertTrue(r.downgraded)

    def test_r1_stale_freezes_stage_and_breach(self):
        # 감리 실측 케이스: B2, A/B stale, prev breach 1
        # 기대: B2 유지·breach 1 동결·강등 없음 (구 구현은 B1 강등했음)
        prev = PersistentState(effective_stage="B2", maintenance_breach_streak=1)
        snap = mk_snapshot(a_state="unconfirmed", a_fresh="stale",
                           b_state="unconfirmed", b_fresh="stale", b_maturity="validated")
        r = self._eval(prev, snap, mk_blockers())
        record_transition("R1: A/B stale -> B2·breach 동결, 강등 없음",
                          ("B2", 1, False),
                          (r.effective_stage, r.maintenance_breach_streak, r.downgraded))
        self.assertEqual(r.effective_stage, "B2")
        self.assertEqual(r.maintenance_breach_streak, 1)
        self.assertFalse(r.downgraded)

    def test_r1_ceiling_downward_still_allowed(self):
        # 예외 확인: active ceiling에 의한 즉시 하향은 강등 미확정이어도 허용
        prev = PersistentState(effective_stage="B3", maintenance_breach_streak=0)
        snap = mk_snapshot(a_state="confirmed", b_state="partial", b_maturity="validated",
                           derivatives_pressure="strong")
        blk = mk_blockers(dl="active")  # ceiling B2
        r = self._eval(prev, snap, blk)
        record_transition("R1: 강등 미확정 + derivatives_led active -> ceiling B2 하향 허용",
                          "B2", r.effective_stage)
        self.assertEqual(r.effective_stage, "B2")
        self.assertFalse(r.downgraded)
        self.assertIn("blocker:derivatives_led", r.ceiling_sources)

    # ── 차단 2: 유지-무관 blocker unknown이 강등을 막지 않음 ─────────
    def test_r1_b4_maintenance_blocker_unknown_freezes(self):
        # 대조 계약: B4 유지 predicate는 파생 blocker를 참조 — unknown이면 동결 유지
        prev = PersistentState(effective_stage="B4", maintenance_breach_streak=1)
        snap = mk_snapshot(a_state="confirmed", b_state="confirmed", b_maturity="validated",
                           e_state="confirmed", derivatives_pressure="unknown")
        blk = mk_blockers(dl="unknown", do="unknown")
        r = self._eval(prev, snap, blk)
        record_transition("R1: B4 유지 관련 blocker unknown -> breach·단계 동결",
                          ("B4", 1, False),
                          (r.effective_stage, r.maintenance_breach_streak, r.downgraded))
        self.assertEqual(r.effective_stage, "B4")
        self.assertEqual(r.maintenance_breach_streak, 1)
        self.assertFalse(r.downgraded)

    # ── 차단 3: spot_weakness confirmed 잔존 streak ──────────────────
    def test_r1_spot_confirmed_with_old_streak_not_active(self):
        # 감리 실측 CASE3: 현재 confirmed + 과거 streak >= W → active 금지
        r = BLK.eval_spot_weakness("confirmed", "fresh", "validated",
                                   confirmed_anchor="2026-07-10.us_close",
                                   weakness_streak=5, history_sufficient=True, cfg=self.cfg)
        record_transition("R1: spot confirmed + 과거 streak>=W -> inactive (active 금지)",
                          "inactive", r)
        self.assertEqual(r, "inactive")

    def test_r1_run_reset_on_confirmed(self):
        # confirmed 복귀 → anchor 갱신 + run 0 초기화
        anchor, streak = BLK.update_spot_weakness_run(
            "2026-07-10.us_close", 5, "confirmed", "fresh", "validated",
            "2026-07-16.us_close")
        record_transition("R1: confirmed 복귀 -> anchor 갱신·run 0",
                          ("2026-07-16.us_close", 0), (anchor, streak))
        self.assertEqual((anchor, streak), ("2026-07-16.us_close", 0))

    def test_r1_run_increments_on_partial(self):
        anchor, streak = BLK.update_spot_weakness_run(
            "2026-07-10.us_close", 1, "partial", "fresh", "validated",
            "2026-07-16.us_close")
        self.assertEqual((anchor, streak), ("2026-07-10.us_close", 2))

    def test_r1_run_frozen_on_preliminary_and_stale(self):
        # preliminary·stale·provisional → anchor/run 불변
        for kw in (dict(is_preliminary=True),
                   dict(spot_freshness="stale"),
                   dict(spot_maturity="provisional")):
            base = dict(prev_anchor="a1", prev_streak=3, spot_state="partial",
                        spot_freshness="fresh", spot_maturity="validated",
                        evaluation_id="e")
            base.update(kw)
            anchor, streak = BLK.update_spot_weakness_run(**base)
            self.assertEqual((anchor, streak), ("a1", 3))

    # ── 차단 4: public writer 권리 게이트 강제 ───────────────────────
    def test_r1_approved_with_blocking_source_not_created(self):
        # 감리 실측 CASE4: approved + blocking_sources 존재 → 파일 미생성
        with tempfile.TemporaryDirectory() as d:
            gate = WR.build_release_gate("approved", "approved",
                                         "2026-07-16T00:00:00Z", canon.RIGHTS_SHA,
                                         blocking_sources=["coinbase_market_data"],
                                         rights_graph_verdict="pass")
            path = WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                               "ok", mk_blockers())
            files = os.listdir(d)
            record_transition("R1: approved + blocking_sources -> 공개 파일 미생성",
                              (None, []), (path, files))
            self.assertIsNone(path)
            self.assertEqual(files, [])

    def test_r1_approved_with_blocking_tests_not_created(self):
        with tempfile.TemporaryDirectory() as d:
            gate = WR.build_release_gate("approved", "approved",
                                         "2026-07-16T00:00:00Z", canon.RIGHTS_SHA,
                                         blocking_tests=["smoke_16b"],
                                         rights_graph_verdict="pass")
            path = WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                               "ok", mk_blockers())
            record_transition("R1: approved + blocking_tests -> 미생성",
                              None, path)
            self.assertIsNone(path)
            self.assertEqual(os.listdir(d), [])

    def test_r1_approved_without_rights_verdict_not_created(self):
        # rights_graph_verdict 기본값(unverified)로는 공개 불가
        with tempfile.TemporaryDirectory() as d:
            gate = WR.build_release_gate("approved", "approved",
                                         "2026-07-16T00:00:00Z", canon.RIGHTS_SHA)
            path = WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                               "ok", mk_blockers())
            record_transition("R1: approved + verdict unverified -> 미생성",
                              None, path)
            self.assertIsNone(path)
            self.assertEqual(os.listdir(d), [])

    def test_r1_gate_from_blocked_closure_not_created(self):
        # 권장 진입점: 실제 closure 결과에서 gate 조립 → blocked closure면 자동 차단
        rights = RightsMatrix.load(BASE)
        graph = RG.DependencyGraph()
        sb = load_source_bindings(BASE)["pillars"]
        for name, pdef in sb.items():
            graph.add_pillar(Pillar(
                axis=pdef["axis"], name=name,
                source_bindings=[SourceBinding.from_dict(b) for b in pdef["bindings"]],
                dependencies=list(pdef.get("dependencies", [])),
            ))
        closure = RG.public_closure_blocked(["spot_demand"], graph, rights)
        gate = WR.gate_from_closure("approved", "approved",
                                    "2026-07-16T00:00:00Z", canon.RIGHTS_SHA, closure)
        self.assertEqual(gate["rights_graph_verdict"], "fail")
        with tempfile.TemporaryDirectory() as d:
            path = WR.write_public_if_approved(d, gate, "2026-07-16", "B2", "회복 2단계",
                                               "ok", mk_blockers())
            record_transition("R1: 실제 blocked closure gate -> 미생성",
                              None, path)
            self.assertIsNone(path)
            self.assertEqual(os.listdir(d), [])


if __name__ == "__main__":
    # 전이 기록을 파일로도 남긴다
    result = unittest.main(exit=False, verbosity=2)
    print("\n" + "=" * 70)
    print("FIXTURE 전이 기대값/실제값 표")
    print("=" * 70)
    for name, exp, act, verdict in TRANSITIONS:
        print(f"[{verdict}] {name}")
        print(f"        기대: {exp}")
        print(f"        실제: {act}")
    out = os.path.join(BASE, "tests", "transitions.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump([{"name": n, "expected": str(e), "actual": str(a), "verdict": v}
                   for n, e, a, v in TRANSITIONS], f, ensure_ascii=False, indent=2)
    sys.exit(0 if result.result.wasSuccessful() else 1)
