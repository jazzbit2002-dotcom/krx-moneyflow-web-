"""
demo_cycle.py — fixture 기반 전체 평가 사이클 1회 시연.

canonical 평가 → shadow 기록 → release gate HOLD → 공개 파일 미생성 확인.
서버·외부 API 없음. 순수 fixture.
"""

import json
import os
import sys
import tempfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from engine import canon
from engine.models import RecoveryConfig
from engine import state_machine as SM
from engine.state_machine import PersistentState, PillarSnapshot
from engine import ledger as LG
from engine.ledger import Ledger, LedgerRecord
from engine import writers as WR


def main():
    print("=== 정본 SHA 재검사 ===")
    result = canon.verify_contracts(BASE)
    for k, v in result.items():
        print(f"  PASS {k[:40]:40s} {v[:16]}...")

    # 테스트 전용 config (NON_NORMATIVE)
    with open(os.path.join(BASE, "tests", "fixtures", "test_config.json")) as f:
        cfg = RecoveryConfig.from_dict(json.load(f)["thresholds"])

    print("\n=== fixture 평가 시나리오: B1 → 파생 주도 → B2 ceiling ===")
    prev = PersistentState(effective_stage="B1")
    snap = PillarSnapshot(
        a_state="confirmed", a_fresh="fresh",
        b_state="partial", b_fresh="fresh", b_maturity="validated",
        e_state="unconfirmed", e_fresh="fresh",
        derivatives_pressure="strong",
    )
    blockers = {"structure_break": "inactive",
                "derivatives_led": "active",
                "derivatives_overheated": "inactive"}
    spot_weakness = {"state": "inactive", "confirmed_anchor": None, "weakness_streak": 0}

    r = SM.evaluate(prev, snap, blockers, spot_weakness, cfg, is_preliminary=False)
    print(f"  candidate_stage : {r.candidate_stage}")
    print(f"  effective_stage : {r.effective_stage}")
    print(f"  ceiling_sources : {r.ceiling_sources}")
    print(f"  stage_age_days  : {r.effective_stage_age_days}")
    print(f"  reproducibility 최소요건 검사 (decision_replay):", end=" ")
    LG.assert_core_repro("decision_replay")
    print("PASS")

    with tempfile.TemporaryDirectory() as tmp:
        shadow_dir = os.path.join(tmp, "snapshots")
        public_dir = os.path.join(tmp, "output")

        print("\n=== shadow 기록 (내부 전용) ===")
        shadow_payload = {
            "market_date": "2026-07-16",
            "evaluation_id": "2026-07-16.us_close",
            "is_canonical": True,
            "candidate_stage": r.candidate_stage,
            "effective_stage": r.effective_stage,
            "ceiling_sources": r.ceiling_sources,
            "promotion_streaks": r.promotion_streaks,
            "blockers": r.blockers,
            "spot_weakness": r.spot_weakness,
            "status": "ok",
        }
        sp = WR.write_shadow_latest(shadow_dir, shadow_payload)
        print(f"  생성: {sp}")

        print("\n=== ledger append (canonical) ===")
        led = Ledger()
        rec = led.append(LedgerRecord("2026-07-16.us_close", "2026-07-16",
                                      "canonical", True, shadow_payload))
        print(f"  evaluation_id={rec.evaluation_id} counted={rec.counted} "
              f"canonical_ptr={led.canonical_index['2026-07-16']}")

        print("\n=== release gate = HOLD → 공개 파일 미생성 ===")
        gate = WR.build_release_gate("hold", "usage_rights_pending",
                                     "2026-07-16T00:00:00Z", canon.RIGHTS_SHA)
        pub = WR.write_public_if_approved(public_dir, gate, "2026-07-16",
                                          r.effective_stage, "회복 2단계", "ok", blockers)
        exists = os.path.exists(public_dir) and os.listdir(public_dir) if os.path.exists(public_dir) else []
        print(f"  public writer 반환: {pub}")
        print(f"  output/ 내용: {exists}")
        assert pub is None and not exists, "HOLD인데 공개 파일이 생성됨 — 계약 위반"
        print("  ✓ HOLD 계약 준수: 공개 파일 없음")

    print("\n=== demo 완료 ===")


if __name__ == "__main__":
    main()
