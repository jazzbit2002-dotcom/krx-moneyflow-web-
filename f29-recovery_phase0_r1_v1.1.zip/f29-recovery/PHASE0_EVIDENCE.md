# F29-RECOVERY Phase 0 제출 증거

- 작성: 2026-07-16 (샌드박스, hostname=vm)
- 범위: Phase 0 fixture 엔진 + Phase 1 릴레이 스크립트 **작성**(미실행)
- 실행 환경: 클라우드 샌드박스. **VPS 직접 접근 없음.** 서버 의존 단계는 릴레이 HOLD.

---

## 0. 정본 SHA 대조 (착수 게이트)

빌드·테스트 시작마다 재검사. 전건 일치 — 중지조건 1(SHA 불일치) 미발생.

| 파일 | 기대 | 실측 | 판정 |
|---|---|---|---|
| RECOVERY_ENGINE_SPEC_v1.0_FINAL.md | ac34c0ec…b5c67 | ac34c0ec…b5c67 | PASS |
| RECOVERY_USAGE_RIGHTS_v0.1.1.json | 7d2c43f8…a9e047 | 7d2c43f8…a9e047 | PASS |
| RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md | e5415943…4ea765 | e5415943…4ea765 | PASS |

---

## 1. 정적 검사

- `python3 -m py_compile engine/*.py tests/*.py` → **ALL OK**
- `bash -n scripts/*.sh` (릴레이 3종) → **전건 OK**

## 2. 단위 테스트

- `python3 tests/test_recovery.py` → **Ran 53 tests / OK** (실패 0)
- `python3 tests/demo_cycle.py` → 전체 1 사이클 시연 PASS

---

## 3. 필수 fixture 전이 (지시서 §필수 테스트 매핑)

| 지시서 fixture | 테스트 | 결과 |
|---|---|---|
| B1 + A confirmed + derivatives_led active → B2 | test_b1_plus_A_confirmed_deriv_led_to_B2 | PASS |
| B4 + 일반 강등 + derivatives_led active → B2 | test_b4_downgrade_deriv_led_to_B2 | PASS |
| B3 + 일반 강등 + overheated active → B2 | test_b3_downgrade_overheated_to_B2 | PASS |
| blocker unknown + 확인된 강등 → 강등 실행 | test_blocker_unknown_confirmed_downgrade_executes | PASS |
| blocker unknown + 강등 없음 → 상향 금지·동결 | test_blocker_unknown_no_downgrade_freezes | PASS |
| provisional B축 → B3 금지 | test_provisional_B_no_B3 | PASS |
| confirmed anchor + partial 1회 → spot_weakness 비활성 | test_spot_weakness_partial_once_inactive | PASS |
| confirmed anchor + partial W회 → spot_weakness 활성 | test_spot_weakness_partial_W_active | PASS |
| structure_break active → B1, streak 0, age 1 | test_structure_break_forces_B1 | PASS |
| late us_close replay 가능 → r1 canonical revision | test_late_us_close_replay_changes_canonical | PASS |
| late us_close replay 불가 → late_data_unapplied | test_late_us_close_replay_impossible | PASS |
| 권리 closure에 pending 1건 → 공개 writer 미생성 | test_public_closure_blocked_by_pending + test_public_not_created_on_hold | PASS |
| rights 정본 SHA 변경 → release approval 무효 | test_rights_sha_change_invalidates + test_approved_but_rights_sha_changed_blocks | PASS |

관제 판정 §6 추가 필수 테스트(정본 SHA 불일치 FAIL, 권리 enum, required/optional binding,
cycle/dangling, transitive closure, active blocker ceiling, preliminary 불변,
canonical 1회 가산, provenance_only 금지, 템플릿 전수, release HOLD) — 전건 커버·PASS.

## 4. rights graph 음성 테스트

| 음성 케이스 | 결과 |
|---|---|
| dangling JSON Pointer | PASS (RightsError) |
| dependency cycle | PASS (GraphError) |
| dangling dependency | PASS (GraphError) |
| unknown source | PASS (RightsError) |
| public_derived pending/blocked closure → 공개 차단 | PASS (blocked: coinbase_market_data) |
| rights 정본 SHA 변경 → approval 무효 | PASS (CanonMismatch) |

## 5. 템플릿 전수 매핑

- 도달 가능 조합 열거: status(2) × structure_break(3) × derivatives_led(3) × derivatives_overheated(3) × stage(5) = **270**
- 매칭: **270 / 270** — 미매칭 0, 중복 0 (우선순위 결정론, 단일 반환)
- 금칙어 검사: 위반 **0** (매수/매도/진입/손절/청산/예측/적중/목표가/신호)

## 6. public_release=hold 공개 파일 미생성 증거

- test_public_not_created_on_hold: gate=hold → writer 반환 None, output/ 빈 목록
- demo_cycle: HOLD 사이클에서 output/ 내용 `[]` 확인
- 번들 내 output/·snapshots/·ledger/·probes/ 는 `.gitkeep`만 — 실제 공개 JSON 없음

## 7. 임계값 은닉 방지 증거

- config/recovery_params.json(운영) = D3/D4/D5/W_downgrade/W_spot_weakness/S_max 전부 **null**, deadline **TBD**
- 연구 가설값(3/5/10/2)은 운영 설정에 부재 (test_hypothesis_values_not_in_runtime PASS)
- 엔진이 null 임계값 사용 시 ThresholdUnset (test_runtime_config_all_null PASS)
- 시험값은 tests/fixtures/test_config.json (NON_NORMATIVE 명시)에만 주입

---

## 8. 미실행 항목 (이번 제출 범위 밖)

- scripts/server_preflight.sh — **작성 완료·미실행** (Sky 릴레이 대기)
- scripts/phase1_tech_probe.sh — **작성 완료·미실행** (Phase 1 릴레이 HOLD)
- scripts/install_phase0.sh — **작성 완료·미실행** (preflight PASS 후 명시 실행)

## 9. 서버 의존 HOLD 항목

- `/root/f29-recovery/` 경로 확정·배치 (preflight 실측 전 선언 금지)
- Phase 1 TECH probe 실제 실행 + F29 내부 JSON 인터페이스 확보
- 실데이터 영속 수집 / Shadow 운영 / 공개 서비스 (스펙 §14·§15 게이트)
- cron·systemd·webroot·server.js·`/recovery/` 공개 라우트 (금지)

## 10. 기존 위험 엔진 무변경 증거

- 이 세션은 샌드박스(hostname=vm). **서버 파일을 생성·수정·삭제한 바 없음** → 기존 위험
  엔진(server.js/pro.html/index.html)은 정의상 무변경.
- 서버측 무변경 SHA 대조는 server_preflight.sh [4] baseline이 Phase 0 배치 전후 동일함으로
  릴레이 확인 예정 (배치 자체가 /root/f29-recovery/ 독립 루트라 /root/f29/ 불가침).
