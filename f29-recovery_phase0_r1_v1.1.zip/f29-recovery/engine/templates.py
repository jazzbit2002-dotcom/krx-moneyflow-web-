"""
templates.py — 결정론적 템플릿 매퍼 (스펙 §12).

우선순위: data_delayed > structure_break > derivatives_led > derivatives_overheated > B1~B5.
상위 하나 매칭 시 하위 무시. 도달 가능한 모든 상태 조합은 정확히 하나에 배정.
미매칭·중복 매칭은 FAIL. 모델 자유생성 없음 — template_id 고정 매핑만.

문구는 초안(placeholder). 최종 문구는 외부 감리 검증 + Sky 승인 전까지 비확정.
compliance: 매수/매도/진입/손절/청산/예측/적중 금칙어 없음.
"""

from __future__ import annotations

TEMPLATE_VERSION = "recovery-copy.1"

# 금칙어 (스펙 §1.1) — 템플릿 문구 검증용
FORBIDDEN_TERMS = [
    "매수", "매도", "진입", "손절", "청산", "예측", "적중",
    "목표가", "신호", "매수 적기",
]


class TemplateError(Exception):
    pass


# 결정론적 템플릿 테이블.
# key = (priority_bucket, stage_code) ; priority_bucket 이 stage 무관이면 stage="*"
TEMPLATES = {
    ("data_delayed", "*"): {
        "template_id": "REC-DELAYED-01",
        "plain_summary": "데이터 지연으로 현재 회복 단계를 갱신하지 못하고 있습니다. 마지막 확정 상태를 유지합니다.",
    },
    ("structure_break", "*"): {
        "template_id": "REC-STRUCTBREAK-01",
        "plain_summary": "가격 구조가 약화되고 현물 수요도 확인되지 않아 회복 근거가 초기화된 상태입니다.",
    },
    ("derivatives_led", "*"): {
        "template_id": "REC-B2-DERIV-LED-01",
        "plain_summary": "가격 반응은 나타났지만 파생 거래 비중이 높아 회복 근거는 아직 제한적인 상태입니다.",
    },
    ("derivatives_overheated", "*"): {
        "template_id": "REC-DERIV-OVERHEAT-01",
        "plain_summary": "현물 수요는 확인됐지만 파생 시장이 과열되어 회복의 지속성은 아직 제한적인 상태입니다.",
    },
    ("stage", "B1"): {
        "template_id": "REC-B1-01",
        "plain_summary": "회복 근거가 아직 확인되지 않은 상태입니다.",
    },
    ("stage", "B2"): {
        "template_id": "REC-B2-01",
        "plain_summary": "초기 회복 반응이 나타난 상태입니다.",
    },
    ("stage", "B3"): {
        "template_id": "REC-B3-01",
        "plain_summary": "복수의 회복 조건이 확인된 상태입니다.",
    },
    ("stage", "B4"): {
        "template_id": "REC-B4-01",
        "plain_summary": "구조적 회복이 확인된 상태입니다.",
    },
    ("stage", "B5"): {
        "template_id": "REC-B5-01",
        "plain_summary": "회복 상태가 지속되고 있는 상태입니다.",
    },
}


def select_template(status: str, blockers: dict, stage_code: str) -> dict:
    """
    우선순위 결정론 매핑. 정확히 하나 반환.
    status: 'ok' | 'data_delayed'
    blockers: {structure_break, derivatives_led, derivatives_overheated: state}
    stage_code: B1~B5 (effective)
    """
    # 1. data_delayed
    if status == "data_delayed":
        return _resolve(("data_delayed", "*"))
    # 2. structure_break
    if blockers.get("structure_break") == "active":
        return _resolve(("structure_break", "*"))
    # 3. derivatives_led
    if blockers.get("derivatives_led") == "active":
        return _resolve(("derivatives_led", "*"))
    # 4. derivatives_overheated
    if blockers.get("derivatives_overheated") == "active":
        return _resolve(("derivatives_overheated", "*"))
    # 5. B1~B5 일반
    if stage_code not in ("B1", "B2", "B3", "B4", "B5"):
        raise TemplateError(f"미매칭: 알 수 없는 stage_code {stage_code}")
    return _resolve(("stage", stage_code))


def _resolve(key) -> dict:
    t = TEMPLATES.get(key)
    if t is None:
        raise TemplateError(f"미매칭: 템플릿 키 {key} 부재")
    out = dict(t)
    out["template_version"] = TEMPLATE_VERSION
    out["match_key"] = key
    return out


def check_forbidden_terms() -> list:
    """모든 템플릿 문구에 금칙어가 없는지 검사. 위반 목록 반환(빈 리스트=PASS)."""
    violations = []
    for key, t in TEMPLATES.items():
        summary = t["plain_summary"]
        for term in FORBIDDEN_TERMS:
            if term in summary:
                violations.append((t["template_id"], term))
    return violations
