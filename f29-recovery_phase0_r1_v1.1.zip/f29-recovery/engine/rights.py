"""
rights.py — usage-rights 정본 로더 + JSON Pointer validator + enum 검증.

스펙 §4(권리·재현성), §13(권리 그래프). 권리 JSON은 코드에 복제하지 않고
정본 파일에서 로드한다(지시서 §금지: "권리 JSON을 코드 안에 복제").
"""

from __future__ import annotations

import json
import os
from typing import Any

from engine import canon


class RightsError(Exception):
    pass


# 권리 enum (정본 JSON의 enums 블록과 대조 검증)
EXPECTED_RIGHTS_ENUM = ["allowed", "pending", "blocked"]
EXPECTED_RAW_RETENTION_ENUM = ["allowed", "pending", "restricted", "blocked"]

# 실행 모드별 필요 권리 키 (스펙 §4.1)
MODE_REQUIRED_RIGHTS = {
    "probe": ["probe"],
    "internal_shadow": ["internal_shadow"],
    "auditable_shadow": [
        "internal_shadow",
        "internal_derived_retention",
    ],
    "public_derived": ["public_derived"],
}


class RightsMatrix:
    def __init__(self, data: dict, sha256: str):
        self.data = data
        self.sha256 = sha256
        self._validate_enums()

    @classmethod
    def load(cls, base: str | None = None) -> "RightsMatrix":
        cdir = canon.contracts_dir(base)
        path = os.path.join(cdir, canon.RIGHTS_FILE)
        if not os.path.exists(path):
            raise RightsError(f"권리 정본 부재: {path}")
        sha = canon.sha256_file(path)
        # 로드 시점에도 SHA 앵커 확인 — 바이트 변경 시 즉시 CanonMismatch
        canon.require_rights_sha(sha)
        with open(path, "rb") as f:
            raw = f.read()
        data = json.loads(raw.decode("utf-8"))
        return cls(data, sha)

    def _validate_enums(self) -> None:
        enums = self.data.get("enums", {})
        if enums.get("rights") != EXPECTED_RIGHTS_ENUM:
            raise RightsError(
                f"rights enum 불일치: {enums.get('rights')} != {EXPECTED_RIGHTS_ENUM}"
            )
        if enums.get("raw_retention") != EXPECTED_RAW_RETENTION_ENUM:
            raise RightsError(
                f"raw_retention enum 불일치: {enums.get('raw_retention')} "
                f"!= {EXPECTED_RAW_RETENTION_ENUM}"
            )
        # 각 소스의 권리 값이 enum 범위 안인지 검증
        rights_ok = set(EXPECTED_RIGHTS_ENUM)
        raw_ok = set(EXPECTED_RAW_RETENTION_ENUM)
        for sid, s in self.data.get("sources", {}).items():
            for key in ("probe", "internal_shadow", "internal_derived_retention",
                        "public_derived", "public_raw"):
                if key in s and s[key] not in rights_ok:
                    raise RightsError(
                        f"소스 {sid}.{key} = {s[key]} — rights enum 밖"
                    )
            if "raw_retention" in s and s["raw_retention"] not in raw_ok:
                raise RightsError(
                    f"소스 {sid}.raw_retention = {s['raw_retention']} — enum 밖"
                )

    # ── JSON Pointer 해석 (RFC6901 부분집합: #/sources/<id>) ──────────
    def resolve_pointer(self, ref: str) -> dict:
        """
        'RECOVERY_USAGE_RIGHTS_v0.1.1.json#/sources/coinbase_market_data'
        형태의 usage_rights_ref를 해석해 소스 dict를 반환.
        해석 실패 시 RightsError (스펙 §13-1: 모든 ref가 해석되는가).
        """
        if "#" not in ref:
            raise RightsError(f"JSON Pointer fragment 없음: {ref}")
        filepart, pointer = ref.split("#", 1)
        if filepart and filepart != canon.RIGHTS_FILE:
            raise RightsError(
                f"권리 ref 파일명 불일치: {filepart} != {canon.RIGHTS_FILE}"
            )
        if not pointer.startswith("/"):
            raise RightsError(f"JSON Pointer 형식 오류: {pointer}")
        node: Any = self.data
        for tok in pointer.split("/")[1:]:
            tok = tok.replace("~1", "/").replace("~0", "~")
            if not isinstance(node, dict) or tok not in node:
                raise RightsError(f"JSON Pointer 해석 실패: {ref} (토큰 '{tok}')")
            node = node[tok]
        if not isinstance(node, dict):
            raise RightsError(f"JSON Pointer가 소스 객체를 가리키지 않음: {ref}")
        return node

    def source(self, source_id: str) -> dict:
        s = self.data.get("sources", {}).get(source_id)
        if s is None:
            raise RightsError(f"권리 정본에 없는 공급원: {source_id}")
        return s

    def right(self, source_id: str, key: str) -> str:
        return self.source(source_id).get(key, "pending")

    def mode_allowed(self, source_id: str, mode: str) -> bool:
        """
        해당 소스가 실행 모드의 필요 권리를 전부 allowed 하는가.
        pending/blocked는 allowed로 추정하지 않는다(지시서 §금지).
        """
        keys = MODE_REQUIRED_RIGHTS.get(mode)
        if keys is None:
            raise RightsError(f"알 수 없는 실행 모드: {mode}")
        s = self.source(source_id)
        return all(s.get(k) == "allowed" for k in keys)
