"""
rights_graph.py — source binding 집계 + 권리 그래프 transitive closure.

스펙 §3.3(집계 규칙), §13(권리 그래프 검사 1~12).
음성 테스트 필수.
"""

from __future__ import annotations

from engine.models import Pillar, SourceBinding
from engine.rights import RightsMatrix, RightsError


class GraphError(Exception):
    pass


# ── §3.3 binding 집계 ────────────────────────────────────────────────
def evaluate_binding_availability(pillar: Pillar) -> dict:
    """
    required binding 하나라도 technical != pass → pillar 사용 불가, freshness=missing.
    optional binding 미달 → 제외 + degraded=true.
    반환: {usable: bool, freshness_override: str|None, degraded: bool, reasons: [...]}
    """
    reasons = []
    usable = True
    freshness_override = None
    degraded = False

    for b in pillar.required_bindings():
        if b.technical != "pass":
            usable = False
            freshness_override = "missing"
            reasons.append(f"required binding {b.source_id} technical={b.technical}")

    for b in pillar.optional_bindings():
        if b.technical != "pass":
            degraded = True
            reasons.append(f"optional binding {b.source_id} degraded (technical={b.technical})")

    return {
        "usable": usable,
        "freshness_override": freshness_override,
        "degraded": degraded,
        "reasons": reasons,
    }


def mode_binding_allowed(pillar: Pillar, rights: RightsMatrix, mode: str) -> dict:
    """
    실행 모드에 필요한 권리를 required binding이 전부 충족하는가.
    미달이면 해당 모드에서 pillar 사용 불가 (스펙 §3.3).
    """
    reasons = []
    ok = True
    for b in pillar.required_bindings():
        if not rights.mode_allowed(b.source_id, mode):
            ok = False
            reasons.append(f"{b.source_id} 권리 미달 (mode={mode})")
    return {"allowed": ok, "reasons": reasons}


# ── §13 권리 그래프 transitive closure ───────────────────────────────
class DependencyGraph:
    """
    pillar/binding 의존 그래프. 노드 = source_id 또는 pillar_name.
    엣지 = pillar → 그 bindings 의 source_id, pillar → dependencies(pillar).
    """

    def __init__(self):
        self.pillar_bindings: dict[str, list[SourceBinding]] = {}
        self.pillar_deps: dict[str, list[str]] = {}

    def add_pillar(self, pillar: Pillar):
        self.pillar_bindings[pillar.name] = list(pillar.source_bindings)
        self.pillar_deps[pillar.name] = list(pillar.dependencies)

    # §13-4/5: cycle·dangling 검사
    def validate_structure(self) -> None:
        # dangling dependency
        for pname, deps in self.pillar_deps.items():
            for d in deps:
                if d not in self.pillar_bindings:
                    raise GraphError(f"존재하지 않는 dependency: {pname} -> {d}")
        # cycle (DFS)
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {p: WHITE for p in self.pillar_bindings}

        def dfs(node, stack):
            color[node] = GRAY
            for nxt in self.pillar_deps.get(node, []):
                if color[nxt] == GRAY:
                    raise GraphError(
                        f"dependency cycle: {' -> '.join(stack + [node, nxt])}"
                    )
                if color[nxt] == WHITE:
                    dfs(nxt, stack + [node])
            color[node] = BLACK

        for p in self.pillar_bindings:
            if color[p] == WHITE:
                dfs(p, [])

    def transitive_sources(self, contributing_pillars: list[str]) -> set[str]:
        """
        공개 산출물에 기여한 pillar 집합 → 전이적 source_id closure.
        pillar dependency를 따라가 상류 pillar의 binding source까지 포함.
        (§13-6/7/8: 직접·간접·blocker 상류·template source 포함)
        """
        seen_pillars: set[str] = set()
        sources: set[str] = set()
        stack = list(contributing_pillars)
        while stack:
            p = stack.pop()
            if p in seen_pillars:
                continue
            seen_pillars.add(p)
            if p not in self.pillar_bindings:
                raise GraphError(f"closure 중 미등록 pillar: {p}")
            for b in self.pillar_bindings[p]:
                sources.add(b.source_id)
            for dep in self.pillar_deps.get(p, []):
                stack.append(dep)
        return sources


def resolve_all_refs(pillars: list[Pillar], rights: RightsMatrix) -> None:
    """§13-1: 모든 usage_rights_ref JSON Pointer가 해석되는가."""
    for p in pillars:
        for b in p.source_bindings:
            rights.resolve_pointer(b.usage_rights_ref)  # 실패 시 RightsError


def public_closure_blocked(
    contributing_pillars: list[str],
    graph: DependencyGraph,
    rights: RightsMatrix,
    used_optional_sources: set[str] | None = None,
) -> dict:
    """
    §13-6~9,11,12: 공개 stage에 기여한 closure의 전 소스가 public_derived=allowed 인가.
    optional macro source는 실제 summary에 쓰였을 때만 closure에 포함(§13-11/12).
    반환: {blocked: bool, blocking_sources: [...], closure: set}
    """
    if used_optional_sources is None:
        used_optional_sources = set()

    closure = graph.transitive_sources(contributing_pillars)

    # optional binding source 중 실제 사용 안 된 것은 공개 closure에서 제외
    optional_sources = set()
    for p in contributing_pillars:
        for b in graph.pillar_bindings.get(p, []):
            if b.role == "optional":
                optional_sources.add(b.source_id)
    excluded = optional_sources - used_optional_sources
    effective_closure = closure - excluded

    blocking = []
    for sid in sorted(effective_closure):
        try:
            pr = rights.right(sid, "public_derived")
        except RightsError:
            raise
        if pr != "allowed":  # pending 또는 blocked
            blocking.append(sid)

    return {
        "blocked": bool(blocking),
        "blocking_sources": blocking,
        "closure": effective_closure,
    }
