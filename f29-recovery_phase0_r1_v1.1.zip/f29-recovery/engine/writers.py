"""
writers.py — shadow / public 출력 writer + release gate (스펙 §11).

물리 분리:
- shadow: 내부 전용. candidate/blocker trace/pillar 포함.
- public: release gate 통과(approved) 시에만 생성. hold이면 파일 절대 미생성.

지시서 §금지: public_release=hold에서 공개 파일 미생성 증거 필수.
"""

from __future__ import annotations

import json
import os

from engine import canon
from engine.templates import select_template

COMPLIANCE_VERSION = "recovery-compliance.1"


class ReleaseGateError(Exception):
    pass


def write_shadow_latest(
    out_dir: str,
    payload: dict,
) -> str:
    """
    내부 shadow latest JSON. 공개 경로 밖(shadow/). 항상 생성 가능.
    """
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "shadow_latest.json")
    body = dict(payload)
    body.setdefault("schema_version", "btc_recovery_shadow.1")
    body["visibility"] = "shadow"
    body["compliance_version"] = COMPLIANCE_VERSION
    body["rights_matrix_sha256"] = canon.RIGHTS_SHA
    with open(path, "w", encoding="utf-8") as f:
        json.dump(body, f, ensure_ascii=False, indent=2)
    return path


def build_release_gate(
    public_release: str,
    reason: str,
    checked_at: str,
    rights_sha: str,
    blocking_sources: list | None = None,
    blocking_tests: list | None = None,
    rights_graph_verdict: str = "unverified",
) -> dict:
    """
    release gate 상태 객체 (스펙 §11.4).
    R1-FIX4: rights_graph_verdict는 rights graph validator가 실제 closure 검사를
    통과했을 때만 'pass'로 설정한다. 기본값 'unverified'는 공개를 차단한다.
    """
    return {
        "schema_version": "recovery_release_gate.1",
        "public_release": public_release,   # hold | approved
        "reason": reason,
        "checked_at": checked_at,
        "rights_matrix_sha256": rights_sha,
        "blocking_sources": blocking_sources or [],
        "blocking_tests": blocking_tests or [],
        "rights_graph_verdict": rights_graph_verdict,  # pass | fail | unverified
    }


def gate_from_closure(
    public_release: str,
    reason: str,
    checked_at: str,
    rights_sha: str,
    closure_result: dict,
    blocking_tests: list | None = None,
) -> dict:
    """
    rights_graph.public_closure_blocked() 결과에서 gate를 직접 조립한다.
    호출자가 blocking_sources/verdict를 임의로 조작하는 경로를 줄이는 권장 진입점.
    """
    blocking = list(closure_result.get("blocking_sources", []))
    verdict = "pass" if not blocking else "fail"
    return build_release_gate(
        public_release=public_release,
        reason=reason,
        checked_at=checked_at,
        rights_sha=rights_sha,
        blocking_sources=blocking,
        blocking_tests=blocking_tests,
        rights_graph_verdict=verdict,
    )


def write_public_if_approved(
    out_dir: str,
    release_gate: dict,
    as_of: str,
    stage_code: str,
    stage_label: str,
    status: str,
    blockers: dict,
) -> str | None:
    """
    R1-FIX4: 공개 JSON은 아래 전 조건 충족 시에만 생성한다.
      1. public_release == approved
      2. blocking_sources == []   (권리 closure 차단 소스 없음)
      3. blocking_tests == []     (차단 테스트 없음)
      4. rights_graph_verdict == pass  (validator가 실제 검증한 gate만)
      5. rights 정본 SHA == 앵커  (변경 시 approval 자동 무효 — CanonMismatch)
    하나라도 미달이면 파일을 절대 생성하지 않는다. 호출자가 'approved' 문자열만
    넣어 권리 그래프를 우회하는 경로를 차단한다.
    """
    if release_gate.get("public_release") != "approved":
        return None  # 파일 미생성
    if release_gate.get("blocking_sources"):
        return None  # 권리 closure 차단 — 미생성
    if release_gate.get("blocking_tests"):
        return None  # 차단 테스트 존재 — 미생성
    if release_gate.get("rights_graph_verdict") != "pass":
        return None  # closure 검증 미실시/실패 — 미생성

    # rights SHA 재검사 — 변경 시 approval 무효
    canon.require_rights_sha(release_gate.get("rights_matrix_sha256", ""))

    tmpl = select_template(status, blockers, stage_code)

    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "public_latest.json")
    body = {
        "schema_version": "btc_recovery_public.1",
        "as_of": as_of,
        "stage_code": stage_code,
        "stage_label": stage_label,
        "template_id": tmpl["template_id"],
        "template_version": tmpl["template_version"],
        "plain_summary": tmpl["plain_summary"],
        "status": status,
        "compliance_version": COMPLIANCE_VERSION,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(body, f, ensure_ascii=False, indent=2)
    return path


def withdraw_public(out_dir: str) -> bool:
    """
    approved -> hold 전환 시 단일 철수 (스펙 §11.4).
    공개 파일 원자적 철수. 반환: 철수 실행 여부.
    """
    path = os.path.join(out_dir, "public_latest.json")
    if os.path.exists(path):
        os.remove(path)
        return True
    return False
