"""
canon.py — 정본(canonical contract) SHA 게이트.

지시서/스펙 §0: 엔진·release gate·테스트는 파일명뿐 아니라 SHA-256까지 확인한다.
권리 정본 바이트가 바뀌면 기존 release approval은 자동 무효.

이 모듈은 빌드/테스트 시작 시마다 호출되어야 하며, 불일치 시 즉시
CanonMismatch를 raise 한다. 자동 보정은 절대 하지 않는다(중지조건 1).
"""

from __future__ import annotations

import hashlib
import os

# ── 정본 3종 SHA-256 (지시서 + manifest 대조 확정값) ──────────────────
CANONICAL_SHA = {
    "RECOVERY_ENGINE_SPEC_v1.0_FINAL.md":
        "ac34c0ec5bc40043bec9e5ffadbeb2891632055c706132d43c83d946528b5c67",
    "RECOVERY_USAGE_RIGHTS_v0.1.1.json":
        "7d2c43f849a51d129d16c731f711ad86e06cdc84875ec240e7825f8acfa9e047",
    "RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md":
        "e5415943fe04f7d3fba21a1698c834e09177637130a3da98cf326069d34ea765",
}

# 권리 정본 파일명 — rights_matrix_sha256 앵커로 재사용
RIGHTS_FILE = "RECOVERY_USAGE_RIGHTS_v0.1.1.json"
RIGHTS_SHA = CANONICAL_SHA[RIGHTS_FILE]


class CanonMismatch(Exception):
    """정본 SHA 불일치. 자동 보정 금지 — 즉시 FAIL/HOLD 보고."""


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def contracts_dir(base: str | None = None) -> str:
    """엔진 루트 기준 contracts/ 경로."""
    if base is None:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "contracts")


def verify_contracts(base: str | None = None) -> dict:
    """
    정본 3종을 재검사한다. 전건 일치 시 {filename: sha} 반환.
    하나라도 불일치·부재 시 CanonMismatch. (자동 보정 없음)
    """
    cdir = contracts_dir(base)
    result = {}
    for name, expected in CANONICAL_SHA.items():
        path = os.path.join(cdir, name)
        if not os.path.exists(path):
            raise CanonMismatch(f"정본 부재: {name} (경로 {path})")
        actual = sha256_file(path)
        if actual != expected:
            raise CanonMismatch(
                f"정본 SHA 불일치: {name}\n  기대 {expected}\n  실측 {actual}"
            )
        result[name] = actual
    return result


def require_rights_sha(observed_sha: str) -> None:
    """
    release gate/closure에서 사용: 관측된 rights 정본 SHA가 앵커와 다르면
    approval 무효(CanonMismatch). 스펙 §13-10.
    """
    if observed_sha != RIGHTS_SHA:
        raise CanonMismatch(
            f"rights 정본 SHA 변경 — release approval 무효\n"
            f"  앵커 {RIGHTS_SHA}\n  관측 {observed_sha}"
        )
