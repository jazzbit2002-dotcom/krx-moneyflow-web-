"""
ledger.py — append-only 평가 원장 (스펙 §9, §11.2).

preliminary/canonical/fallback/revision 전부 보존. canonical 포인터만 이동.
동일 evaluation_id 재실행은 멱등(카운터 재가산 없음).
late us_close → replay → 결과 다를 때만 canonical revision.
"""

from __future__ import annotations

from dataclasses import dataclass, field


class LedgerError(Exception):
    pass


# 재현성 등급 (스펙 §4.2)
REPRO_RANK = {"provenance_only": 0, "decision_replay": 1, "full": 2}


def repro_at_least(level: str, minimum: str) -> bool:
    return REPRO_RANK.get(level, -1) >= REPRO_RANK[minimum]


def assert_core_repro(level: str) -> None:
    """A/B/C/E 등 단계·blocker를 바꾸는 입력은 최소 decision_replay (스펙 §4.2)."""
    if not repro_at_least(level, "decision_replay"):
        raise LedgerError(
            f"핵심축 재현성 부족: {level} < decision_replay (provenance_only 금지)"
        )


@dataclass
class LedgerRecord:
    evaluation_id: str        # YYYY-MM-DD.{daily|us_close|daily_fallback|us_close.rN}
    market_date: str
    kind: str                 # preliminary | canonical | fallback | revision
    is_canonical: bool
    payload: dict
    supersedes: str | None = None
    revision_reason: str | None = None
    counted: bool = False     # 영속 카운터 가산 여부 (멱등 보장)


class Ledger:
    def __init__(self):
        self.records: list[LedgerRecord] = []          # append-only
        self.canonical_index: dict[str, str] = {}      # market_date -> evaluation_id
        self._by_id: dict[str, LedgerRecord] = {}
        self._counted_market_dates: set[str] = set()   # canonical 1회 가산 추적

    # ── 조회 ─────────────────────────────────────────────────────────
    def get(self, evaluation_id: str) -> LedgerRecord | None:
        return self._by_id.get(evaluation_id)

    def canonical_for(self, market_date: str) -> LedgerRecord | None:
        eid = self.canonical_index.get(market_date)
        return self._by_id.get(eid) if eid else None

    # ── append ───────────────────────────────────────────────────────
    def append(self, rec: LedgerRecord) -> LedgerRecord:
        """
        멱등: 동일 evaluation_id 재실행은 payload를 갱신하되 카운터는 재가산 안 함.
        """
        existing = self._by_id.get(rec.evaluation_id)
        if existing is not None:
            # 결과 덮어쓰기 허용, counted 플래그·카운터 상태 보존
            existing.payload = rec.payload
            existing.is_canonical = rec.is_canonical
            existing.supersedes = rec.supersedes
            existing.revision_reason = rec.revision_reason
            if rec.is_canonical:
                self.canonical_index[rec.market_date] = rec.evaluation_id
            return existing

        # 신규 append
        self.records.append(rec)
        self._by_id[rec.evaluation_id] = rec

        if rec.kind == "preliminary":
            # 영속 카운터 반영 금지 (스펙 §9.2)
            rec.counted = False
        elif rec.kind in ("canonical", "fallback", "revision") and rec.is_canonical:
            # market_date당 canonical 1회 가산 (스펙 §9.2)
            if rec.market_date not in self._counted_market_dates:
                rec.counted = True
                self._counted_market_dates.add(rec.market_date)
            else:
                rec.counted = False
            self.canonical_index[rec.market_date] = rec.evaluation_id
        return rec

    # ── §9.4 late us_close ──────────────────────────────────────────
    def apply_late_us_close(
        self,
        market_date: str,
        replay_possible: bool,
        replayed_payload: dict | None,
        fallback_eid: str,
        revision_index: int = 1,
    ) -> LedgerRecord:
        """
        fallback 최종화 이후 늦은 us_close 도착 처리.
        - replay 가능 & 결과 상이 → canonical revision(rN) 생성, 포인터 이동
        - replay 가능 & 결과 동일 → revision 레코드는 남기되 canonical 유지(no-op 포인터)
        - replay 불가 → fallback 유지 + late_data_unapplied
        fallback 레코드는 절대 삭제하지 않음(§9.4-4).
        """
        fb = self._by_id.get(fallback_eid)
        if fb is None:
            raise LedgerError(f"fallback 레코드 부재: {fallback_eid}")

        if not replay_possible:
            # late_data_unapplied — fallback을 canonical로 유지
            note_eid = f"{market_date}.us_close.late_unapplied"
            rec = LedgerRecord(
                evaluation_id=note_eid,
                market_date=market_date,
                kind="revision",
                is_canonical=False,
                payload={"late_data_unapplied": True},
                supersedes=None,
                revision_reason="late_us_close_replay_impossible",
            )
            self.append(rec)
            # canonical 포인터는 fallback 유지
            self.canonical_index[market_date] = fallback_eid
            return rec

        # replay 가능
        result_changed = replayed_payload != fb.payload
        rev_eid = f"{market_date}.us_close.r{revision_index}"
        if result_changed:
            rec = LedgerRecord(
                evaluation_id=rev_eid,
                market_date=market_date,
                kind="revision",
                is_canonical=True,
                payload=dict(replayed_payload),
                supersedes=fallback_eid,
                revision_reason="late_us_close_arrival",
            )
            self.append(rec)
            self.canonical_index[market_date] = rev_eid
            return rec
        else:
            # 결과 동일 — revision 레코드 보존, canonical 포인터 이동 없음
            rec = LedgerRecord(
                evaluation_id=rev_eid,
                market_date=market_date,
                kind="revision",
                is_canonical=False,
                payload=dict(replayed_payload),
                supersedes=None,
                revision_reason="late_us_close_no_change",
            )
            self.append(rec)
            self.canonical_index[market_date] = fallback_eid
            return rec
