"""
state_machine.py — B1~B5 상태기계 (스펙 §7, §8).

핵심 계약:
- unknown은 승급을 막지만 확인된 강등은 막지 않는다.
- active blocker는 자기 ceiling까지 이동 허용.
- 강등 확정 평가에서는 같은 평가 내 재승급 금지, ceiling은 추가 하향만.
- preliminary 평가는 영속 카운터(streak/age) 불변.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from engine.models import RecoveryConfig
from engine import blockers as B

STAGE_ORDINAL = {"B1": 1, "B2": 2, "B3": 3, "B4": 4, "B5": 5}
ORDINAL_STAGE = {v: k for k, v in STAGE_ORDINAL.items()}


def stage_min(*stages: str) -> str:
    return ORDINAL_STAGE[min(STAGE_ORDINAL[s] for s in stages)]


@dataclass
class PersistentState:
    """평가 간 이어지는 영속 상태."""
    effective_stage: str = "B1"
    effective_stage_age_days: int = 0
    promotion_streaks: dict = field(default_factory=lambda: {"B3": 0, "B4": 0, "B5": 0})
    maintenance_breach_streak: int = 0

    def copy(self) -> "PersistentState":
        return PersistentState(
            effective_stage=self.effective_stage,
            effective_stage_age_days=self.effective_stage_age_days,
            promotion_streaks=dict(self.promotion_streaks),
            maintenance_breach_streak=self.maintenance_breach_streak,
        )


@dataclass
class PillarSnapshot:
    """평가 시점 pillar 상태 요약 (fixture 입력)."""
    a_state: str          # structure
    a_fresh: str
    b_state: str          # spot_demand
    b_fresh: str
    b_maturity: str       # provisional | validated
    e_state: str          # breadth
    e_fresh: str
    derivatives_pressure: str
    e_reconfirm_ok: bool = False  # B5 재확인 조건


# ── §7.1 단계 자격 predicate (지속일 제외 = 유지 predicate) ────────────
def qualifies_b2(p: PillarSnapshot) -> bool:
    # A 또는 B 중 최소 1축 confirmed
    return p.a_state == "confirmed" or p.b_state == "confirmed"


def qualifies_b3_core(p: PillarSnapshot) -> bool:
    # A confirmed, B confirmed, B validated (지속일 제외)
    return (
        p.a_state == "confirmed"
        and p.b_state == "confirmed"
        and p.b_maturity == "validated"
    )


def qualifies_b4_core(p: PillarSnapshot, blockers: dict) -> bool:
    return (
        qualifies_b3_core(p)
        and p.e_state == "confirmed"
        and blockers.get("derivatives_led") == "inactive"
        and blockers.get("derivatives_overheated") == "inactive"
    )


def qualifies_b5_core(p: PillarSnapshot, blockers: dict) -> bool:
    return qualifies_b4_core(p, blockers) and p.e_reconfirm_ok


# ── 필요 입력 fresh 여부 (streak 갱신용) ──────────────────────────────
def inputs_fresh_for(stage: str, p: PillarSnapshot) -> bool:
    # R1-FIX1: B2 유지 freshness는 A/B 기준 — B2에서도 stale이면 동결돼야 한다.
    if stage == "B2":
        return p.a_fresh == "fresh" and p.b_fresh == "fresh"
    if stage == "B3":
        return p.a_fresh == "fresh" and p.b_fresh == "fresh"
    if stage == "B4":
        return p.a_fresh == "fresh" and p.b_fresh == "fresh" and p.e_fresh == "fresh"
    if stage == "B5":
        return p.a_fresh == "fresh" and p.b_fresh == "fresh" and p.e_fresh == "fresh"
    return True


def any_blocker_unknown(blockers: dict) -> bool:
    return any(v == "unknown" for v in blockers.values())


# ── candidate stage 계산 (강등 없을 때) ───────────────────────────────
def compute_candidate(p: PillarSnapshot, blockers: dict, streaks: dict,
                      cfg: RecoveryConfig) -> str:
    """
    pillar + streak로 도달 가능한 최고 candidate 단계.
    상위부터 검사; 지속일(D3/D4/D5)은 test_config에서 주입.
    """
    # B5
    if qualifies_b5_core(p, blockers):
        cfg.require("D5")
        if streaks.get("B5", 0) >= cfg.D5:
            return "B5"
    # B4
    if qualifies_b4_core(p, blockers):
        cfg.require("D4")
        if streaks.get("B4", 0) >= cfg.D4:
            return "B4"
    # B3
    if qualifies_b3_core(p):
        cfg.require("D3")
        if streaks.get("B3", 0) >= cfg.D3:
            return "B3"
    # B2
    if qualifies_b2(p):
        return "B2"
    return "B1"


# ── 유지 predicate (§7.2): 현재 단계 자격에서 지속일만 제외 ────────────
def maintenance_ok(stage: str, p: PillarSnapshot, blockers: dict) -> bool:
    if stage == "B2":
        return qualifies_b2(p)
    if stage == "B3":
        return qualifies_b3_core(p)
    if stage == "B4":
        return qualifies_b4_core(p, blockers)
    if stage == "B5":
        return qualifies_b5_core(p, blockers)
    return True  # B1 하한


def maintenance_inputs_fresh(stage: str, p: PillarSnapshot) -> bool:
    if stage == "B1":
        return True  # B1은 하한 — 유지 판정 불필요
    return inputs_fresh_for(stage, p)


def maintenance_blockers_unknown(stage: str, blockers: dict) -> bool:
    """
    R1-FIX2: 유지 predicate가 실제로 참조하는 blocker가 unknown인가.
    B4/B5 유지조건만 derivatives_led/overheated를 참조한다.
    무관한 blocker unknown은 fresh 입력으로 확인된 훼손·강등을 막지 않는다
    (정본: unknown은 승급을 막지만 확인된 강등은 막지 않는다).
    """
    if stage in ("B4", "B5"):
        return (
            blockers.get("derivatives_led") == "unknown"
            or blockers.get("derivatives_overheated") == "unknown"
        )
    return False


@dataclass
class EvalResult:
    candidate_stage: str
    effective_stage: str
    ceiling_applied: list
    ceiling_sources: list
    downgraded: bool
    structure_break: bool
    promotion_streaks: dict
    maintenance_breach_streak: int
    effective_stage_age_days: int
    blockers: dict
    spot_weakness: dict
    frozen_reason: str | None


def evaluate(
    prev: PersistentState,
    p: PillarSnapshot,
    blockers: dict,
    spot_weakness: dict,
    cfg: RecoveryConfig,
    is_preliminary: bool = False,
) -> EvalResult:
    """
    스펙 §8.1 canonical 평가 순서 구현.
    is_preliminary=True면 영속 streak/age 불변(스펙 §8.2, §8.3, §9.2).
    """
    st = prev.copy()
    ceiling_sources: list = []

    # ── 3. structure_break active → 즉시 B1, 종료 ────────────────────
    if blockers.get("structure_break") == "active":
        new_stage = "B1"
        if not is_preliminary:
            st.promotion_streaks = {"B3": 0, "B4": 0, "B5": 0}
            _apply_age(st, new_stage)
            st.effective_stage = new_stage
        return EvalResult(
            candidate_stage="B1",
            effective_stage=new_stage,
            ceiling_applied=[],
            ceiling_sources=["blocker:structure_break"],
            downgraded=False,
            structure_break=True,
            promotion_streaks=dict(st.promotion_streaks),
            maintenance_breach_streak=st.maintenance_breach_streak,
            effective_stage_age_days=st.effective_stage_age_days,
            blockers=dict(blockers),
            spot_weakness=dict(spot_weakness),
            frozen_reason=None,
        )

    # ── 4. 유지조건 fresh 훼손 streak 갱신 ───────────────────────────
    cur = prev.effective_stage
    breach_frozen = False
    if maintenance_inputs_fresh(cur, p):
        if maintenance_ok(cur, p, blockers):
            new_breach = 0
        else:
            new_breach = prev.maintenance_breach_streak + 1
    else:
        # stale/missing → 훼손 횟수 동결
        new_breach = prev.maintenance_breach_streak
        breach_frozen = True
    # R1-FIX2: 유지 predicate가 참조하는 blocker(B4/B5의 파생 blocker)가 unknown일 때만
    # 동결. 무관한 blocker unknown은 fresh 입력으로 확인된 훼손·강등을 막지 않는다.
    if maintenance_blockers_unknown(cur, blockers):
        new_breach = prev.maintenance_breach_streak
        breach_frozen = True

    if not is_preliminary:
        st.maintenance_breach_streak = new_breach

    # ── 5. 일반 강등 확정 판정 ───────────────────────────────────────
    downgrade = False
    if cur != "B1" and not breach_frozen:
        cfg.require("W_downgrade")
        if new_breach >= cfg.W_downgrade:
            downgrade = True

    # ── 6A. 일반 강등 확정 ───────────────────────────────────────────
    if downgrade:
        downgrade_target = ORDINAL_STAGE[max(1, STAGE_ORDINAL[cur] - 1)]
        if not is_preliminary:
            # 모든 상위 promotion streak 초기화
            st.promotion_streaks = {"B3": 0, "B4": 0, "B5": 0}
        ceils = B.active_ceilings(blockers)
        final_stage = downgrade_target
        for c in ceils:
            ceiling_sources.append(_ceiling_source_name(c, blockers))
            final_stage = stage_min(final_stage, c)
        if not is_preliminary:
            st.maintenance_breach_streak = 0  # 강등 실행 후 리셋
            _apply_age(st, final_stage)
            st.effective_stage = final_stage
        return EvalResult(
            candidate_stage=downgrade_target,  # 강등 평가는 candidate 재계산 안 함
            effective_stage=final_stage,
            ceiling_applied=ceils,
            ceiling_sources=ceiling_sources,
            downgraded=True,
            structure_break=False,
            promotion_streaks=dict(st.promotion_streaks),
            maintenance_breach_streak=st.maintenance_breach_streak,
            effective_stage_age_days=st.effective_stage_age_days,
            blockers=dict(blockers),
            spot_weakness=dict(spot_weakness),
            frozen_reason=None,
        )

    # ── 6B. 강등 없음 ────────────────────────────────────────────────
    frozen_reason = None
    # b. fresh 조건으로 promotion streak 갱신 (canonical만)
    working_streaks = dict(prev.promotion_streaks)
    if not is_preliminary:
        working_streaks = _update_streaks(prev.promotion_streaks, p, blockers, cfg)
        st.promotion_streaks = working_streaks

    # a. blocker unknown이면 상향 이동 금지 → candidate를 현재 이하로 clamp
    candidate = compute_candidate(p, blockers, working_streaks, cfg)
    if any_blocker_unknown(blockers):
        frozen_reason = "blocker_unknown_no_promotion"
        # 상향 금지: candidate가 현재보다 높으면 현재로 억제
        if STAGE_ORDINAL[candidate] > STAGE_ORDINAL[prev.effective_stage]:
            candidate = prev.effective_stage

    # R1-FIX1: 강등 미확정 평가에서는 candidate가 현재 단계보다 낮아도 단계를
    # 내리지 않는다. 일반 하강은 오직 6A(W_downgrade회 확인 강등) 경로.
    # active blocker ceiling에 의한 즉시 하향만 예외로 허용한다.
    promotion_target = candidate
    if STAGE_ORDINAL[promotion_target] < STAGE_ORDINAL[prev.effective_stage]:
        promotion_target = prev.effective_stage

    # d. active blocker ceiling 적용
    ceils = B.active_ceilings(blockers)
    effective = promotion_target
    for c in ceils:
        ceiling_sources.append(_ceiling_source_name(c, blockers))
        effective = stage_min(effective, c)

    # maturity provisional → ceiling 표기 (B가 provisional이면 B3+ 자격 자체 불충족이나
    # ceiling_sources 투명성 위해 기록)
    if p.b_maturity == "provisional":
        ceiling_sources.append("maturity:spot_demand:provisional")

    if not is_preliminary:
        _apply_age(st, effective)
        st.effective_stage = effective

    return EvalResult(
        candidate_stage=candidate,
        effective_stage=effective,
        ceiling_applied=ceils,
        ceiling_sources=ceiling_sources,
        downgraded=False,
        structure_break=False,
        promotion_streaks=dict(st.promotion_streaks),
        maintenance_breach_streak=st.maintenance_breach_streak,
        effective_stage_age_days=st.effective_stage_age_days,
        blockers=dict(blockers),
        spot_weakness=dict(spot_weakness),
        frozen_reason=frozen_reason,
    )


def _update_streaks(prev_streaks: dict, p: PillarSnapshot, blockers: dict,
                    cfg: RecoveryConfig) -> dict:
    """
    §8.2: 단계별 필요 입력 fresh + 자격 predicate → +1 / 0 / 동결.
    상위 실패 시 그 위 단계도 0.
    """
    s = dict(prev_streaks)
    quals = {
        "B3": qualifies_b3_core(p),
        "B4": qualifies_b4_core(p, blockers),
        "B5": qualifies_b5_core(p, blockers),
    }
    for stage in ("B3", "B4", "B5"):
        if inputs_fresh_for(stage, p):
            if quals[stage]:
                s[stage] = s.get(stage, 0) + 1
            else:
                s[stage] = 0
                # 상위 단계도 0
                for higher in ("B4", "B5"):
                    if STAGE_ORDINAL[higher] > STAGE_ORDINAL[stage]:
                        s[higher] = 0
        # else: 동결 (입력 stale/missing)
    return s


def _apply_age(st: PersistentState, new_stage: str) -> None:
    if new_stage != st.effective_stage:
        st.effective_stage_age_days = 1
    else:
        st.effective_stage_age_days += 1


def _ceiling_source_name(ceiling: str, blockers: dict) -> str:
    for name, ceil in B.CEILING.items():
        if ceil == ceiling and blockers.get(name) == "active":
            return f"blocker:{name}"
    return f"ceiling:{ceiling}"
