"""
models.py — 공통 데이터 계약 모델 (스펙 §3).

정규화 관측치, pillar 상태, source binding, 설정 로더.
fixture 기반이므로 외부 I/O 없이 dict → 모델 변환만 담당한다.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any

# ── enum 상수 ─────────────────────────────────────────────────────────
PILLAR_STATES = ("adverse", "unconfirmed", "partial", "confirmed")
FRESHNESS = ("fresh", "stale", "missing")
MATURITY = ("provisional", "validated")
TECHNICAL = ("unprobed", "pass", "fail")
REPRODUCIBILITY = ("full", "decision_replay", "provenance_only")
REPRO_RANK = {"provenance_only": 0, "decision_replay": 1, "full": 2}
BLOCKER_STATES = ("active", "inactive", "unknown")
DERIV_PRESSURE = ("normal", "strong", "overheated", "unknown")


@dataclass
class Observation:
    """정규화 관측치 (스펙 §3.1)."""
    metric_id: str
    value: float
    state: str
    observation_time: str
    available_at: str
    evaluation_cutoff: str
    unit: str = "provider_defined_normalized"
    ingested_at: str | None = None
    source_revision: str | None = None
    timezone: str = "UTC"
    freshness: str = "fresh"
    non_point_in_time: bool = False

    def usable_at_cutoff(self) -> bool:
        # available_at <= evaluation_cutoff 인 값만 사용 (스펙 §3.1)
        return self.available_at <= self.evaluation_cutoff


@dataclass
class SourceBinding:
    """pillar의 source binding (스펙 §3.3)."""
    source_id: str
    dataset_id: str
    role: str  # required | optional
    technical: str  # unprobed | pass | fail
    usage_rights_ref: str
    reproducibility: str  # full | decision_replay | provenance_only
    conditions: list = field(default_factory=list)
    decision_owner: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "SourceBinding":
        return cls(
            source_id=d["source_id"],
            dataset_id=d["dataset_id"],
            role=d["role"],
            technical=d.get("technical", "unprobed"),
            usage_rights_ref=d["usage_rights_ref"],
            reproducibility=d.get("reproducibility", "provenance_only"),
            conditions=list(d.get("conditions", [])),
            decision_owner=d.get("decision_owner", ""),
        )


@dataclass
class Pillar:
    """pillar 레코드 (스펙 §3.2)."""
    axis: str  # A~E
    name: str
    state: str = "unconfirmed"
    freshness: str = "fresh"
    maturity: str = "validated"
    degraded: bool = False
    role: str = ""
    source_bindings: list = field(default_factory=list)  # list[SourceBinding]
    dependencies: list = field(default_factory=list)
    features: list = field(default_factory=list)
    decision_trace: list = field(default_factory=list)

    def required_bindings(self):
        return [b for b in self.source_bindings if b.role == "required"]

    def optional_bindings(self):
        return [b for b in self.source_bindings if b.role == "optional"]


# ── 설정 로더 ─────────────────────────────────────────────────────────
def load_json(path: str) -> dict:
    with open(path, "rb") as f:
        return json.loads(f.read().decode("utf-8"))


def config_dir(base: str | None = None) -> str:
    if base is None:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "config")


@dataclass
class RecoveryConfig:
    """
    규범 임계값 컨테이너. 운영 기본은 전부 None(=null/TBD).
    fixture 테스트는 별도 test_config로 명시적 시험값을 주입한다.
    """
    D3: int | None = None
    D4: int | None = None
    D5: int | None = None
    W_downgrade: int | None = None
    W_spot_weakness: int | None = None
    S_max_daily: int | None = None
    S_max_weekly: int | None = None
    us_close_deadline_utc: str = "TBD"

    @classmethod
    def from_runtime(cls, base: str | None = None) -> "RecoveryConfig":
        p = load_json(os.path.join(config_dir(base), "recovery_params.json"))
        return cls(
            D3=p["promotion_dwell"]["D3"],
            D4=p["promotion_dwell"]["D4"],
            D5=p["promotion_dwell"]["D5"],
            W_downgrade=p["downgrade"]["W_downgrade"],
            W_spot_weakness=p["spot_weakness"]["W_spot_weakness"],
            S_max_daily=p["stale_max"]["S_max_daily"],
            S_max_weekly=p["stale_max"]["S_max_weekly"],
            us_close_deadline_utc=p["fallback"]["us_close_deadline_utc"],
        )

    @classmethod
    def from_dict(cls, d: dict) -> "RecoveryConfig":
        """테스트 전용 설정 주입용. d는 test_config.json의 thresholds 블록."""
        return cls(
            D3=d.get("D3"),
            D4=d.get("D4"),
            D5=d.get("D5"),
            W_downgrade=d.get("W_downgrade"),
            W_spot_weakness=d.get("W_spot_weakness"),
            S_max_daily=d.get("S_max_daily"),
            S_max_weekly=d.get("S_max_weekly"),
            us_close_deadline_utc=d.get("us_close_deadline_utc", "TBD"),
        )

    def require(self, *names: str) -> None:
        """
        엔진이 특정 임계값을 필요로 할 때 호출. None이면 ThresholdUnset.
        운영 설정(전부 null)에서 상태기계를 돌리려 하면 여기서 막힌다 —
        연구 가설값이 몰래 채워지지 않았음을 런타임에 보장.
        """
        missing = [n for n in names if getattr(self, n) is None]
        if missing:
            raise ThresholdUnset(
                f"규범 임계값 미설정: {missing}. 운영 설정은 null/TBD이며 "
                f"시험값은 test_config에서만 주입한다."
            )


class ThresholdUnset(Exception):
    """규범 임계값이 null인데 엔진이 사용하려 함."""


def load_source_bindings(base: str | None = None) -> dict:
    """config/source_bindings.json → {pillar_name: {...}}."""
    return load_json(os.path.join(config_dir(base), "source_bindings.json"))
