"""
blockers.py — 파생 상태와 blocker (스펙 §6).

모든 blocker는 active | inactive | unknown.
필요 입력이 stale/missing/unbound/판정불가이면 inactive가 아니라 unknown.
"""

from __future__ import annotations

from dataclasses import dataclass
from engine.models import RecoveryConfig


@dataclass
class BlockerInputs:
    """blocker 판정에 필요한 정규화 입력 스냅샷."""
    spot_state: str            # adverse|unconfirmed|partial|confirmed
    spot_freshness: str        # fresh|stale|missing
    spot_maturity: str         # provisional|validated
    structure_state: str       # adverse|unconfirmed|partial|confirmed
    structure_freshness: str
    derivatives_pressure: str  # normal|strong|overheated|unknown


CEILING = {
    "derivatives_led": "B2",
    "derivatives_overheated": "B3",
}


def _fresh(*vals: str) -> bool:
    return all(v == "fresh" for v in vals)


# ── §6.1 spot_weakness ────────────────────────────────────────────────
def eval_spot_weakness(
    spot_state: str,
    spot_freshness: str,
    spot_maturity: str,
    confirmed_anchor: str | None,
    weakness_streak: int,
    history_sufficient: bool,
    cfg: RecoveryConfig,
) -> str:
    """
    structure_break 입력용 파생 상태.
    provisional B축은 여기서도 unknown으로 흐른다(스펙 §6.1 unknown 조건).
    """
    # unknown 우선 판정
    if spot_freshness in ("stale", "missing"):
        return "unknown"
    if spot_maturity == "provisional":
        return "unknown"
    if not history_sufficient:
        return "unknown"

    # active 경로 1: adverse + fresh + validated
    if spot_state == "adverse" and spot_freshness == "fresh" and spot_maturity == "validated":
        return "active"

    # R1-FIX3: run 경로는 현재 상태가 partial | unconfirmed 일 때만 성립한다.
    # 현재 confirmed인데 과거 weakness_streak 잔존만으로 active가 되면 안 된다.
    if spot_state not in ("partial", "unconfirmed"):
        return "inactive"

    # active 경로 2: confirmed anchor 이후 약화 run W회
    # anchor가 필요한데 없으면 unknown
    if confirmed_anchor is None:
        return "unknown"
    cfg.require("W_spot_weakness")
    if weakness_streak >= cfg.W_spot_weakness:
        return "active"

    return "inactive"


def update_spot_weakness_run(
    prev_anchor: str | None,
    prev_streak: int,
    spot_state: str,
    spot_freshness: str,
    spot_maturity: str,
    evaluation_id: str,
    is_preliminary: bool = False,
) -> tuple:
    """
    R1-FIX3: confirmed-anchor / weakness-run 영속 갱신 (canonical 평가 전용).

    - confirmed(fresh·validated) 복귀 → anchor = 이번 evaluation_id, run = 0 (초기화)
    - partial|unconfirmed(fresh·validated) & anchor 존재 → run += 1
    - anchor 부재 → run 미정의(동결)
    - stale/missing/provisional/preliminary → anchor·run 불변(동결)
    - adverse → run 불변 (adverse는 경로 1에서 즉시 판정, run 카운트 아님)

    반환: (anchor, streak)
    """
    if is_preliminary:
        return prev_anchor, prev_streak
    if spot_freshness != "fresh" or spot_maturity != "validated":
        return prev_anchor, prev_streak
    if spot_state == "confirmed":
        return evaluation_id, 0
    if spot_state in ("partial", "unconfirmed"):
        if prev_anchor is None:
            return prev_anchor, prev_streak
        return prev_anchor, prev_streak + 1
    return prev_anchor, prev_streak  # adverse


# ── §6.2 derivatives_led ─────────────────────────────────────────────
def eval_derivatives_led(inp: BlockerInputs) -> str:
    if inp.derivatives_pressure == "unknown":
        return "unknown"
    if inp.spot_freshness in ("stale", "missing"):
        return "unknown"
    if (
        inp.derivatives_pressure in ("strong", "overheated")
        and inp.spot_state != "confirmed"
        and _fresh(inp.spot_freshness)
    ):
        return "active"
    if _fresh(inp.spot_freshness):
        return "inactive"
    return "unknown"


# ── §6.3 derivatives_overheated ──────────────────────────────────────
def eval_derivatives_overheated(inp: BlockerInputs) -> str:
    if inp.derivatives_pressure == "unknown":
        return "unknown"
    if inp.spot_freshness in ("stale", "missing"):
        return "unknown"
    if (
        inp.derivatives_pressure == "overheated"
        and inp.spot_state == "confirmed"
        and _fresh(inp.spot_freshness)
    ):
        return "active"
    if _fresh(inp.spot_freshness):
        return "inactive"
    return "unknown"


# ── §6.4 structure_break ─────────────────────────────────────────────
def eval_structure_break(inp: BlockerInputs, spot_weakness_state: str) -> str:
    """
    active: structure adverse AND spot_weakness active AND deriv in {strong,overheated}
            AND 필요 입력 전부 fresh.
    unknown: 필요 입력 중 하나라도 stale/missing/unknown/unbound.
    """
    # unknown 우선: 필요 입력 판정 불가
    if inp.derivatives_pressure == "unknown":
        return "unknown"
    if inp.structure_freshness in ("stale", "missing"):
        return "unknown"
    if inp.spot_freshness in ("stale", "missing"):
        return "unknown"
    if spot_weakness_state == "unknown":
        return "unknown"

    if (
        inp.structure_state == "adverse"
        and spot_weakness_state == "active"
        and inp.derivatives_pressure in ("strong", "overheated")
        and _fresh(inp.structure_freshness, inp.spot_freshness)
    ):
        return "active"
    return "inactive"


def active_ceilings(blockers: dict) -> list[str]:
    """active blocker의 ceiling 목록 (structure_break는 별도 즉시 B1 처리)."""
    out = []
    for name, ceil in CEILING.items():
        if blockers.get(name) == "active":
            out.append(ceil)
    return out
