# RECOVERY_ENGINE_SPEC_v1.0_FINAL

- 문서 지위: **RATIFIED / NORMATIVE**
- 작성·비준: 외부 감리 최종 설계
- 기준일: 2026-07-16
- 목적: 비트코인 위험지수와 독립적으로 작동하는 회복 확인 상태기계의 구현 계약
- production 공개: **HOLD**
- 영속 Shadow: **권리·보존·인터페이스 게이트 충족 전 HOLD**
- TECH probe, fixture 기반 엔진·검증기·테스트 구현: **APPROVED**

## 0. 정본 의존성

### 0.1 usage-rights 기계 정본

```text
file    = RECOVERY_USAGE_RIGHTS_v0.1.1.json
SHA-256 = 7d2c43f849a51d129d16c731f711ad86e06cdc84875ec240e7825f8acfa9e047
status  = MACHINE_CANONICAL
```

엔진, release gate, 테스트는 파일명뿐 아니라 SHA-256까지 확인한다. 권리 정본의 바이트가 바뀌면 기존 release approval은 자동 무효다.

### 0.2 연구 가설 문서

```text
file    = RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md
SHA-256 = e5415943fe04f7d3fba21a1698c834e09177637130a3da98cf326069d34ea765
status  = NON_NORMATIVE
```

연구 가설의 숫자는 구현 기본값이 아니다. 모든 규범 파라미터는 본 스펙에서 `TBD`이며, 별도 설정 파일로만 주입한다.

---

# 1. 제품 계약

## 1.1 감지와 집행의 분리

컴플라이언스 정본은 다음 하나다.

```text
[recovery-compliance.1]
회복지수는 시장 상태를 기록하고 설명하는 지표다.
매수·매도·비중 확대·진입 시점·손절 규칙을 지시하지 않는다.
회복 단계는 사용자의 기존 투자 원칙이나 집행 규칙을 변경하지 않는다.
본 지표는 예측이 아니며, 과거 동일 상태 이후의 가격 분포만을 사후 통계로 제공한다.
```

금지:

- 매수 적기, 진입 신호, 매도 신호, 목표가, 손절가, 적중률, 예측 같은 표현
- 회복 단계가 포트폴리오 비중이나 주문 규칙을 자동 변경하는 기능
- 모델이 공개 요약문을 자유 생성하는 기능

JSON은 문구를 복제하지 않고 `compliance_version: recovery-compliance.1`만 저장한다.

## 1.2 위험축과 회복축의 독립

```text
R1~R5 = 변동성·청산·레버리지 위험 상태
B1~B5 = 회복 근거의 확인 정도와 지속성
```

두 상태기계는 합산, 차감, 역산하지 않는다. `R5+B2`, `R3+B4`, `R1+B1`은 모두 유효하다.

회복 엔진은 기존 위험 엔진의 정규화 산출을 읽기 전용으로 소비한다. 기존 위험 엔진 코드와 `server.js`에 회복 로직을 혼입하지 않는다.

---

# 2. 시스템 경계와 구성요소

권장 독립 루트:

```text
/root/f29-recovery/
├── config/
│   ├── recovery_params.json
│   ├── source_bindings.json
│   └── release_policy.json
├── contracts/
│   ├── RECOVERY_ENGINE_SPEC_v1.0_FINAL.md
│   ├── RECOVERY_USAGE_RIGHTS_v0.1.1.json
│   └── RECOVERY_RESEARCH_HYPOTHESES_v0.1.1.md
├── adapters/
├── engine/
├── ledger/
├── snapshots/
├── output/
├── probes/
└── tests/
```

구성요소:

1. `source adapters`: 공급자 원자료를 정규화 feature와 point-in-time 메타로 변환
2. `pillar evaluators`: A~E 축의 시장 상태 산출
3. `blocker evaluator`: 파생 주도·과열·구조 붕괴 판정
4. `state machine`: candidate stage, ceiling, effective stage, streak, 강등 처리
5. `rights graph validator`: 기술·권리·재현성·공개 전이 권리 검사
6. `evaluation ledger`: preliminary, canonical, fallback, revision을 append-only로 기록
7. `shadow writer`: 내부 전용 결과·decision trace 저장
8. `public writer`: release gate 통과 시에만 공개 JSON 생성
9. `template renderer`: 승인된 결정론적 문장만 출력

---

# 3. 공통 데이터 계약

## 3.1 정규화 관측치

모든 입력은 최소 다음 필드를 가진다.

```json
{
  "metric_id": "spot_cvd_state",
  "value": 0.0,
  "unit": "provider_defined_normalized",
  "state": "adverse|unconfirmed|partial|confirmed",
  "observation_time": "2026-07-16T00:00:00Z",
  "available_at": "2026-07-16T00:10:00Z",
  "ingested_at": "2026-07-16T00:11:00Z",
  "evaluation_cutoff": "2026-07-16T21:30:00Z",
  "source_revision": "provider_revision_or_null",
  "timezone": "UTC",
  "freshness": "fresh|stale|missing",
  "non_point_in_time": false
}
```

규칙:

- `available_at <= evaluation_cutoff`인 값만 해당 평가에 사용
- cutoff 이후 도착분은 다음 평가 또는 revision에서만 사용
- 백필은 first print를 우선 사용
- first print를 확보할 수 없으면 `non_point_in_time=true`
- `non_point_in_time` 관측은 walk-forward 성능 주장에 사용 금지

## 3.2 pillar 상태

```text
adverse | unconfirmed | partial | confirmed
```

`adverse`는 회복 반대 증거가 확인된 **시장 상태**다. 기술 실패, 권리 차단, 데이터 결측과 혼용하지 않는다.

각 pillar 레코드:

```json
{
  "state": "confirmed",
  "freshness": "fresh",
  "maturity": "provisional|validated",
  "degraded": false,
  "source_bindings": [],
  "dependencies": [],
  "features": [],
  "decision_trace": []
}
```

## 3.3 source binding

pillar는 단일 `source_status`가 아니라 복수 binding을 가진다.

```json
{
  "source_id": "vendor_or_feed_id",
  "dataset_id": "btc_usd_trades",
  "role": "required|optional",
  "technical": "unprobed|pass|fail",
  "usage_rights_ref": "RECOVERY_USAGE_RIGHTS_v0.1.1.json#/sources/<source_id>",
  "reproducibility": "full|decision_replay|provenance_only",
  "conditions": [],
  "decision_owner": "supplier_contract|auditor|upstream_f29_audit"
}
```

집계 규칙:

- required binding 하나라도 `technical != pass`면 pillar는 사용 불가, `freshness=missing`
- 실행 모드에 필요한 권리 하나라도 미달이면 pillar는 해당 모드에서 사용 불가
- optional binding 미달은 해당 구성요소를 제외하고 `degraded=true`
- 모든 binding과 dependency는 rights graph에 등록돼야 한다

---

# 4. 권리와 재현성 계약

## 4.1 실행 모드별 권리

### TECH probe

```text
probe == allowed
```

읽기 전용 응답·필드·지연·문서 확인만 허용한다. TECH_PASS는 LICENSE_PASS가 아니다.

### 비영속 내부 실험

```text
internal_shadow == allowed
```

프로세스 메모리에서 단기 검증할 수 있으나 결과·feature를 영속 저장하지 않는다.

### 감사 가능한 Shadow

모든 핵심 binding에 다음이 필요하다.

```text
technical == pass
internal_shadow == allowed
internal_derived_retention == allowed
reproducibility >= decision_replay
```

원자료를 저장하려면 추가로 `raw_retention` 권리를 충족해야 한다.

### 공개 파생 결과

공개 `stage_code`, `template_id`, `plain_summary`에 직접·간접적으로 기여한 **전 소스**가 다음을 충족해야 한다.

```text
public_derived == allowed
```

원자료 수치를 공개하지 않으므로 `public_raw`는 기본 공개 게이트에 사용하지 않는다. 향후 원자료 표시를 추가하려면 별도 비준이 필요하다.

## 4.2 재현성 등급

```text
full
  허용된 원문 스냅샷 보존. 원천부터 재감사 가능.

decision_replay
  당시 정규화 feature와 버전으로 엔진 판정 재실행 가능.
  원천 추출 정확성까지 완전 재감사할 수는 없음.

provenance_only
  시각·버전·digest만 보존. 판정 재실행 불가.
```

A, B, C, E처럼 단계나 blocker를 바꾸는 입력은 최소 `decision_replay`가 필요하다. `provenance_only`는 전면 금지한다.

D macro는 MVP context-only이므로 provenance-only를 내부 참고 태그로만 사용할 수 있다. 단계, 임계값, 공개 summary, template 선택에는 사용하지 않는다.

## 4.3 decision_replay 최소 저장물

```text
정규화 feature vector
feature_schema_version
전처리·집계 코드 SHA
엔진 코드 SHA
설정·임계값 파일 SHA
observation_time / available_at / ingested_at / evaluation_cutoff
공급자·엔드포인트·요청 파라미터 식별값
source_revision 또는 sequence 범위
원응답 digest
발화 규칙과 blocker decision trace
usage-rights 정본 SHA
```

---

# 5. 회복 축 정의

## A. structure — 가격·원가 구조

역할: 핵심 승급축.

필요 측정:

- BTC 확정 일봉 종가
- 전시장 Realized Price 또는 동등한 원가선
- 가격의 원가선 상회 여부와 유지 구조
- 원가선 기울기
- 고점·저점 구조

MVRV, MVRV Z-Score는 context 전용이다. 낮다는 이유만으로 승급할 수 없다.

## B. spot_demand — 현물 수요

역할: 핵심 승급축. 초기 `maturity=provisional`.

필요 측정:

- USD 현물 체결 기반 CVD 또는 동등한 현물 방향성
- 현물 거래량 지속성
- 복수 USD 현물 합성 기준가 대비 프리미엄

단일 USDT 시장과의 단순 비교를 금지한다.

`provisional`인 B축은:

- B2 보조 근거로만 사용 가능
- B3·B4 필수축 충족에 사용 금지
- `structure_break`의 하드 강등 입력에 사용 금지

## C. derivatives_quality — 파생 품질

역할: blocker 전용. 점수를 만들지 않는다.

입력:

- 기존 F29 위험 엔진의 정규화 `derivatives_pressure`
- B축의 정규화 `state`, `freshness`, `maturity`

C축은 raw CVD, OI, 펀딩, 청산 값을 다시 독립 점수화하지 않는다.

정규화 인터페이스:

```text
derivatives_pressure = normal | strong | overheated | unknown
```

실제 F29 JSON 필드 바인딩은 서버 샘플과 필드 사전을 감사한 뒤 adapter에서만 수행한다.

## D. macro — 매크로·유동성

역할: MVP context-only.

- 단계 승급·강등에 직접 사용하지 않음
- Shadow 결과를 금리·달러·유동성 환경별로 분해하는 분석 태그
- 공개 summary에 사용하려면 최소 decision_replay와 public_derived 권리 필요

## E. breadth — 시장 확산

역할:

- B1~B3에는 사용하지 않음
- B4 진입 필수
- B5 지속 시 재확인 필수

필요 측정:

- ETH/BTC 상대 추세
- 상위 비스테이블 자산의 추세 회복 비율
- BTC 제외 시가총액 추세 또는 동등한 확산 지표

BTC dominance 하락 단독은 확산으로 인정하지 않는다.

---

# 6. 파생 상태와 blocker

모든 blocker는:

```text
active | inactive | unknown
```

필요 입력이 stale, missing, unbound, 판정 불가이면 `inactive`로 간주하지 않고 `unknown`이다.

## 6.1 spot_weakness

`structure_break` 입력용 파생 상태다.

```text
spot_weakness = active | inactive | unknown
```

### active

다음 중 하나:

1. `spot_demand.state == adverse`
   - freshness=fresh
   - maturity=validated

2. confirmed anchor 이후 약화 run이 W회 연속
   - `confirmed_anchor`: 약화 run 직전에 존재한 마지막 fresh·validated·confirmed canonical 평가
   - `weakness_streak`: anchor 다음 canonical 평가부터 fresh·validated partial 또는 unconfirmed가 연속된 횟수
   - `weakness_streak >= W_spot_weakness`

### unknown

- B축 stale 또는 missing
- B축 maturity=provisional
- confirmed anchor가 필요한데 존재하지 않음
- 전이 이력이 부족함

### inactive

위 active와 unknown이 아닌 경우.

규범 파라미터:

```text
W_spot_weakness = TBD
최소 이력 = confirmed anchor 1건 + W건
```

## 6.2 derivatives_led

```text
active:
  derivatives_pressure in {strong, overheated}
  AND spot_demand.state != confirmed
  AND 필요한 입력 전부 fresh

unknown:
  derivatives_pressure == unknown
  OR spot_demand freshness in {stale, missing}

inactive:
  입력 전부 fresh이며 active 조건 불성립
```

효과:

```text
ceiling = B2
```

## 6.3 derivatives_overheated

```text
active:
  derivatives_pressure == overheated
  AND spot_demand.state == confirmed
  AND 필요한 입력 전부 fresh

unknown:
  derivatives_pressure == unknown
  OR spot_demand freshness in {stale, missing}

inactive:
  입력 전부 fresh이며 active 조건 불성립
```

효과:

```text
ceiling = B3
```

## 6.4 structure_break

```text
active:
  structure.state == adverse
  AND spot_weakness == active
  AND derivatives_pressure in {strong, overheated}
  AND 필요한 입력 전부 fresh

unknown:
  필요 입력 중 하나라도 stale, missing, unknown, unbound

inactive:
  입력 전부 판정 가능하며 active 조건 불성립
```

효과:

```text
즉시 B1
모든 promotion streak = 0
effective_stage_age_days = 1
평가 종료
```

---

# 7. B1~B5 상태 정의

```text
B1 회복 근거 미확인
B2 초기 회복 반응
B3 복수 조건 확인
B4 구조적 회복 확인
B5 회복 상태 지속
```

공개 화면은 `B` 문자를 노출하지 않고 `회복 1단계`처럼 표시한다. 내부 API는 안정적인 `stage_code=B1...B5`를 사용한다.

## 7.1 단계 자격 조건

```text
B1
  기본 상태

B2
  A 또는 B 중 최소 1축 confirmed

B3
  A confirmed
  B confirmed
  B maturity=validated
  promotion_streaks.B3 >= D3

B4
  A confirmed
  B confirmed
  B maturity=validated
  E confirmed
  promotion_streaks.B4 >= D4
  derivatives_led == inactive
  derivatives_overheated == inactive

B5
  B4의 핵심 조건 유지
  promotion_streaks.B5 >= D5
  E가 설정된 재확인 조건을 충족
```

규범 파라미터:

```text
D3 = TBD
D4 = TBD
D5 = TBD
```

## 7.2 단계 유지 조건

단계 유지 predicate는 해당 단계의 자격 조건에서 지속일 수치만 제외한 조건이다.

- fresh 상태에서 유지 predicate가 false이면 유지조건 훼손 1회
- stale, missing, blocker unknown이면 훼손 횟수를 늘리지 않고 동결
- `W_downgrade`회 연속 훼손 시 일반 강등

```text
W_downgrade = TBD
```

---

# 8. 상태기계 알고리즘

stage ordinal:

```text
B1=1, B2=2, B3=3, B4=4, B5=5
```

## 8.1 canonical 평가 순서

```text
1. binding·권리·재현성·freshness 검증
2. pillar state와 spot_weakness, blocker 산출
3. structure_break == active이면 B1 적용 후 종료
4. 현재 단계 유지조건의 fresh 훼손 streak 갱신
5. 일반 강등이 확정됐는지 판정
6A. 일반 강등 확정 시:
    a. downgrade_target = 현재 effective_stage에서 1단계 하강
    b. 모든 상위 promotion streak 초기화
    c. active blocker ceiling을 추가 적용
    d. final_stage = min(downgrade_target, active ceilings)
    e. 같은 평가에서 승급 candidate 계산 금지
6B. 일반 강등이 없을 때:
    a. blocker unknown이 있으면 상향 이동 금지
    b. fresh 조건으로 promotion streak 갱신
    c. pillar와 streak로 candidate_stage 계산
    d. active blocker ceiling 적용
    e. effective_stage = min(candidate_stage, active ceilings)
7. stage age, canonical ledger, output 갱신
```

핵심 규칙:

```text
unknown은 승급을 막는다.
unknown이 확인된 강등까지 막지는 않는다.

active blocker는 승급 전면 금지가 아니다.
자기 ceiling까지는 이동할 수 있다.

강등이 확정된 평가에서는 같은 평가 내 재승급을 금지한다.
ceiling은 강등 결과를 추가 하향할 수만 있다.
```

예시:

```text
현재 B4
일반 강등 → B3
derivatives_led active → ceiling B2
최종 B2
```

```text
현재 B3
일반 강등 → B2
derivatives_overheated active → ceiling B3
최종 B2
```

## 8.2 promotion streak

canonical 평가에서만 영속 갱신한다.

```text
단계 X의 필요 입력이 모두 fresh이고 자격 predicate 충족:
  promotion_streaks[X] += 1

필요 입력이 모두 fresh이고 자격 predicate 불충족:
  promotion_streaks[X] = 0
  X보다 상위 단계 streak도 0

필요 입력 stale/missing 또는 관련 blocker unknown:
  해당 streak 동결

preliminary 평가:
  모든 영속 streak 불변
```

## 8.3 stage age

```text
effective_stage 변경:
  effective_stage_age_days = 1

effective_stage 유지:
  effective_stage_age_days += 1

preliminary 평가:
  age 불변
```

---

# 9. 평가 사이클과 원장

## 9.1 market date

`market_date`는 미국 거래일이다. 모든 실제 시각은 UTC 별도 필드로 저장한다.

## 9.2 평가 종류

```text
daily
  preliminary
  영속 stage·streak·age 확정 금지
  내부 임시 스냅샷만 생성

us_close
  해당 market_date의 canonical 평가
  영속 카운터 반영은 market_date당 최대 1회

daily_fallback
  us_close가 deadline까지 미도착한 경우에만 canonical로 최종화
```

`evaluation_id`:

```text
YYYY-MM-DD.daily
YYYY-MM-DD.us_close
YYYY-MM-DD.daily_fallback
YYYY-MM-DD.us_close.r1
```

동일 `evaluation_id` 재실행은 멱등이다. 결과를 덮어쓸 수 있지만 카운터를 재가산하지 않는다.

## 9.3 fallback deadline

```text
fallback_deadline
= 필수 us_close 입력 중 가장 늦은 정상 available_at
+ probe로 실측한 지연 여유
```

정확한 시각은 설정 파일에 둔다.

```json
{
  "us_close_deadline_utc": "TBD",
  "deadline_basis_version": "recovery-sla.1"
}
```

## 9.4 late us_close

fallback 최종화 이후 늦은 us_close가 도착하면:

1. 별도 평가 레코드로 저장
2. 영향 market_date부터 상태기계를 replay
3. 결과가 달라질 때만 canonical revision 생성
4. 기존 fallback 레코드는 삭제하지 않음
5. 재생이 불가능하면 fallback을 canonical로 유지하고 `late_data_unapplied` 기록

```json
{
  "evaluation_id": "2026-07-16.us_close.r1",
  "supersedes": "2026-07-16.daily_fallback",
  "revision_reason": "late_us_close_arrival",
  "is_canonical": true
}
```

원장은 append-only다. canonical 포인터만 이동한다.

---

# 10. stale와 데이터 지연

소스별 `S_max`는 설정값이며 규범상 TBD다.

```text
핵심축 stale <= S_max
  effective stage 동결
  승급 금지
  status=data_delayed

핵심축 stale > S_max
  공개 stage 출력 중단
  내부 stage는 동결
  release gate에 data_delayed 기록
```

영업일 시계열은 주말·정상 휴장일을 stale 일수에 포함하지 않는다.

stale가 무기한 유지되는 공개 단계는 금지한다.

---

# 11. 출력 계약

## 11.1 내부 Shadow latest

공개 경로 밖에 둔다.

```json
{
  "schema_version": "btc_recovery_shadow.1",
  "visibility": "shadow",
  "market_date": "2026-07-16",
  "evaluation_id": "2026-07-16.us_close",
  "is_canonical": true,
  "supersedes": "2026-07-16.daily",
  "candidate_stage": "B3",
  "effective_stage": "B2",
  "ceiling": "B2",
  "ceiling_sources": [
    "maturity:spot_demand:provisional",
    "blocker:derivatives_led"
  ],
  "effective_stage_age_days": 2,
  "promotion_streaks": {"B3": 2, "B4": 0, "B5": 0},
  "maintenance_breach_streak": 0,
  "blockers": {
    "derivatives_led": "active",
    "derivatives_overheated": "inactive",
    "structure_break": "inactive"
  },
  "spot_weakness": {
    "state": "inactive",
    "confirmed_anchor": "2026-07-14.us_close",
    "weakness_streak": 0
  },
  "pillars": {},
  "status": "ok|data_delayed",
  "reproducibility": "full|decision_replay",
  "rights_matrix_sha256": "7d2c43f849a51d129d16c731f711ad86e06cdc84875ec240e7825f8acfa9e047",
  "engine_code_sha256": "...",
  "config_sha256": "...",
  "inputs_snapshot_sha256": "...",
  "compliance_version": "recovery-compliance.1"
}
```

## 11.2 내부 원장

권장:

```text
ledger/evaluations.jsonl
ledger/canonical_index.json
ledger/revisions.jsonl
```

모든 preliminary, canonical, fallback, revision을 보존한다.

## 11.3 공개 JSON

release gate 통과 시에만 생성한다.

```json
{
  "schema_version": "btc_recovery_public.1",
  "as_of": "2026-07-16",
  "stage_code": "B2",
  "stage_label": "회복 2단계",
  "template_id": "REC-B2-DERIV-LED-01",
  "template_version": "recovery-copy.1",
  "plain_summary": "가격 반응은 나타났지만 파생 거래 비중이 높아 회복 근거는 아직 제한적인 상태입니다.",
  "status": "ok|data_delayed",
  "compliance_version": "recovery-compliance.1"
}
```

금지:

- candidate stage
- pillar 원자료
- 내부 blocker trace
- usage-rights 세부
- 모델 자유문장

## 11.4 release gate

비공개 파일:

```json
{
  "schema_version": "recovery_release_gate.1",
  "public_release": "hold|approved",
  "reason": "usage_rights_pending|data_delayed|tests_failed|approved",
  "checked_at": "2026-07-16T00:00:00Z",
  "rights_matrix_sha256": "7d2c43f849a51d129d16c731f711ad86e06cdc84875ec240e7825f8acfa9e047",
  "blocking_sources": [],
  "blocking_tests": []
}
```

권리가 `approved -> hold`로 바뀌면 단일 철수 절차로:

1. 공개 파일 원자적 철수
2. 캐시 무효화
3. 공개 라우트 unavailable 전환

---

# 12. 결정론적 템플릿

우선순위:

```text
1. data_delayed
2. structure_break
3. derivatives_led
4. derivatives_overheated
5. B1~B5 일반 상태
```

상위 우선순위 하나가 매칭되면 하위 템플릿은 무시한다.

템플릿 작성 절차:

1. 구현 스레드가 전체 매핑표와 초안 작성
2. 외부 감리가 상태 논리, 금칙어, 컴플라이언스 검증
3. Sky가 사용자 노출 문구 최종 승인

공개 JSON은 `template_id`, `template_version`, 렌더링 결과를 함께 기록한다.

모든 도달 가능한 상태 조합은 정확히 하나의 템플릿에 배정돼야 한다. 미매칭과 중복 매칭은 모두 FAIL이다.

---

# 13. 권리 그래프 검사

공개 산출물에 기여한 전이적 소스 집합을 dependencies 그래프로 계산한다.

필수 테스트:

1. 모든 `usage_rights_ref` JSON Pointer가 해석되는가
2. required binding 누락을 FAIL로 잡는가
3. optional binding 누락은 degraded로만 처리하는가
4. dependency cycle이 없는가
5. 존재하지 않는 dependency를 FAIL로 잡는가
6. 공개 stage에 직접·간접 기여한 소스가 closure에 전부 포함되는가
7. blocker를 통해 기여한 C축 상류 소스가 포함되는가
8. template 선택에 사용된 source가 closure에 포함되는가
9. closure 중 `public_derived`가 pending 또는 blocked면 공개 생성이 차단되는가
10. rights 정본 SHA가 달라지면 release approval이 무효가 되는가
11. summary에서 사용하지 않은 optional macro source는 공개 closure에서 제외되는가
12. summary에서 macro를 사용하면 D축 상류가 closure에 포함되는가

음성 테스트는 필수다.

---

# 14. Shadow 범위와 게이트

## 14.1 최소 Shadow — B1~B3

필요 축:

```text
A structure
B spot_demand
C derivatives_quality
```

착수 조건:

- A·B required binding TECH_PASS
- A·B `internal_shadow=allowed`
- A·B `internal_derived_retention=allowed`
- A·B 재현성 최소 decision_replay
- F29 C축 실제 JSON 샘플, 필드 사전, 단위, 시각, 결측 계약
- C 상류의 내부 사용·파생 보존 권리 확인
- 상태기계·rights graph·템플릿 테스트 PASS

## 14.2 전체 Shadow — B1~B5

최소 Shadow 조건에 E축을 추가한다.

- E required binding TECH_PASS
- E internal_shadow와 internal_derived_retention allowed
- E 최소 decision_replay

## 14.3 D macro

MVP context-only이므로 Shadow 엔진 착수 필수조건이 아니다. 국면별 분석을 추가할 때 별도 게이트로 연다.

## 14.4 기간과 검증

- 60~90일
- 화면 완전 비노출
- 7일, 30일, 90일 사후 가격 분포
- 최대 중간 하락폭
- 국면별 분포
- 설계 구간과 검증 구간 분리
- blocker 경계는 미래 수익률을 보지 않고 고정
- 사후 수익률에 맞춘 임계값 소급 조정 금지

---

# 15. 공개 게이트

공개 구현과 라우트 개방은 다음 전부가 충족될 때만 별도 승인한다.

```text
1. 최소 또는 전체 Shadow 완료
2. TECH_PASS
3. 모든 전이적 source public_derived=allowed
4. 권리 정본 SHA 고정
5. release gate 승인
6. 템플릿 전수 테스트 PASS
7. rights graph 테스트 PASS
8. point-in-time·revision 재생 테스트 PASS
9. 외부 감리 비준
10. Sky 공개 결정
```

현재 상태는 `public_release=hold`다.

---

# 16. 구현 단계

## Phase 0 — 정적 골격과 fixture 엔진

승인 범위:

- 디렉터리와 계약 파일 배치
- JSON Schema 또는 동등한 validator
- fixture 기반 pillar·blocker·state machine 구현
- canonical ledger와 replay 구현
- rights graph validator
- template mapper와 전수 테스트
- 공개 writer는 생성하되 release gate가 hold이면 파일을 절대 만들지 않는 테스트

외부 API 연결과 영속 실제 데이터 수집은 금지한다.

## Phase 1 — TECH probe

읽기 전용 probe만 수행한다.

- 응답 필드
- 이력 범위
- 정상 available_at과 지연 분포
- 결측·revision 정책
- 호출 제한
- F29 내부 JSON 인터페이스

결과는 TECH_PASS/FAIL만 갱신한다. usage-rights 값은 감리 승인 없이 수정하지 않는다.

## Phase 2 — adapter 및 비영속 실험

`internal_shadow=allowed` 소스에 한해 메모리 기반 adapter 검증을 수행한다. 파생값을 영속 저장하지 않는다.

## Phase 3 — 최소 Shadow

§14.1 게이트를 모두 통과한 뒤 별도 승인으로 시작한다.

## Phase 4 — 전체 Shadow

E축 권리·기술·보존 게이트가 닫힌 뒤 시작한다.

## Phase 5 — 공개

§15 전건 통과 전 착수 금지.

---

# 17. 완료 증거

각 구현 차수는 최소 다음을 제출한다.

```text
변경 파일 목록
변경 전·후 SHA-256과 bytes
정적 검사 결과
단위 테스트 결과
fixture 상태 전이 전수표
rights graph 음성 테스트
템플릿 미매칭·중복 0건
canonical/fallback/revision replay 증거
public_release=hold에서 공개 파일 미생성 증거
기존 위험 엔진 파일 무변경 SHA 증거
```

금지:

- 라이브 경로에 `.bak` 생성
- 권리 pending 소스의 영속 저장
- 권리 JSON을 코드 안에 복제
- 수치 임계값 하드코딩
- 기존 위험 엔진 수정
- 승인 전 `/recovery/` 공개 라우트 생성

---

# 18. 최종 상태

```text
제품 개념                  RATIFIED
엔진 아키텍처              RATIFIED
상태기계 알고리즘          RATIFIED
권리·재현성 모델           RATIFIED
TECH probe                 APPROVED
fixture 기반 개발          APPROVED
비영속 adapter 실험         권리별 조건부
영속 Shadow                HOLD
공개 서비스                HOLD
```

본 문서는 과거 초안 없이 단독으로 해석·구현할 수 있는 최종 규범 정본이다.
