# RECOVERY_RESEARCH_HYPOTHESES_v0.1.1

- status: `NON_NORMATIVE`
- 작성: 외부 감리 최종 설계 / 2026-07-16
- 지위: 연구 가설 전용. 이 문서의 값은 확정값, 기본값, 구현 상수가 아니다.
- 사용 규칙: Shadow 또는 walk-forward에서 시험한 뒤 별도 비준을 받아야 규범 설정값으로 승격된다.
- 변경 규칙: 정본 스펙이나 설정이 바뀌어도 이 문서는 자동 변경되지 않는다. 후보값을 바꾸려면 문서를 개정하고 새 SHA-256을 발급한다.

## H1. 승급 지속일 후보

- `D3 = 3` canonical 평가일
- `D4 = 5` canonical 평가일
- `D5 = 10` canonical 평가일

검증 기준: 진동 빈도, 탐지 지연, 단계별 체류 분포, 별도 검증 구간의 안정성.

## H2. stale 최대 유지기간 후보

- 일간 소스: 3영업일
- 주간 소스: 12일

소스별 정상 `available_at` 분포와 지연 꼬리를 probe한 뒤 개별 확정한다.

## H3. blocker 경계 연구 절차

수치 후보는 이 문서에도 두지 않는다.

1. 상승 구간의 정규화 OI, 펀딩, 청산, 현물 상태 분포를 산출한다.
2. 파생 주도, 혼합, 현물 주도 사례를 사람이 라벨링한다.
3. 미래 수익률을 보지 않고 분류 경계를 고정한다.
4. 고정된 경계를 별도 Shadow 구간에서 검증한다.
5. 사후 수익률에 맞춘 소급 조정을 금지한다.

초기 라벨링 표본 규모 후보: 상승 사례 30건 이상, 세 유형을 균형 표집.

## H4. 현물 약화 확인일 후보

- `W_spot_weakness = 2` canonical 평가일
- 의미: 마지막 fresh, validated, confirmed anchor 이후 partial 또는 unconfirmed가 연속된 횟수.
- 최소 필요 이력: confirmed anchor 1건 + 약화 관측 W건.

`W_spot_weakness`가 변경되면 이 문서를 개정하고 새 SHA-256을 발급한다.

## H5. 일반 강등 확인일 후보

- `W_downgrade = 2` canonical 평가일

fresh 상태에서 단계 유지 조건이 연속으로 훼손된 횟수다. stale, missing, blocker unknown은 훼손 횟수에 포함하지 않는다.

## H6. fallback deadline 여유 후보

- 필수 입력의 정상 `available_at` 지연 분포 `p99 + 30분`

실측 전 참고치이며 운영 설정으로 사용할 수 없다.
