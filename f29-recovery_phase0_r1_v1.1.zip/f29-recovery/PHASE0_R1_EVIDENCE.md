# F29-RECOVERY PHASE0-R1 보정 증거 (2026-07-16)

- 범위: 관제 판정 **차단 4건만** 수정. 리팩터링·ledger 변경·Phase 1 확대·분석축 추가 없음.
- 정본 3종 SHA: 착수 전 재검사 **전건 PASS** (바이트 무변경).
- 원 Phase 0 증거는 PHASE0_EVIDENCE.md 참조. 본 문서는 R1 차수 추가분.

## 1. 수정 4건 — 변경 파일 전후 SHA·bytes

| 파일 | 변경 전 SHA / bytes | 변경 후 SHA / bytes |
|---|---|---|
| engine/state_machine.py | ef421839… / 12,440 | d9d5f349… / 13,900 |
| engine/blockers.py | 9db69f95… / 4,770 | 3d2e1db5… / 6,230 |
| engine/writers.py | 71495d8a… / 3,426 | 8f6d6437… / 5,235 |
| tests/test_recovery.py | 5d82e15b… / 28,721 | 4ac7f64f… / 39,828 |

그 외 파일 무변경 (MANIFEST.md 전건 지문 대조 가능).

### FIX1 — 강등 미확정 시 하강 금지 (state_machine.py)
- 6B 경로에 `promotion_target = max(prev_effective, candidate)` 도입. 일반 하강은 6A(W회 확인 강등) 전용, **active ceiling 하향만 예외**.
- B2 유지 freshness를 A/B 기준으로 구현(`inputs_fresh_for("B2")`), B1 명시 True. stale → breach·단계 모두 동결.

### FIX2 — blocker unknown이 확인된 강등을 막지 않음 (state_machine.py)
- 전역 `any_blocker_unknown` breach 동결 제거 → `maintenance_blockers_unknown(stage)`: **유지 predicate가 실제 참조하는 blocker(B4/B5의 파생 blocker)가 unknown일 때만** 동결.
- 승급 금지(unknown clamp)는 기존 유지 — "unknown은 승급을 막지만 확인된 강등은 막지 않는다" 계약 충족.

### FIX3 — spot_weakness 잔존 streak (blockers.py)
- run 경로 active는 **현재 spot_state ∈ {partial, unconfirmed}일 때만**. 현재 confirmed + 과거 streak ≥ W → inactive.
- `update_spot_weakness_run()` 신설: confirmed 복귀 → anchor 갱신·run 0 초기화 / partial·unconfirmed → +1 / anchor 부재·stale·provisional·preliminary → 동결.

### FIX4 — public writer 권리 게이트 강제 (writers.py)
- 생성 조건 전건 강제: `public_release==approved` ∧ `blocking_sources==[]` ∧ `blocking_tests==[]` ∧ `rights_graph_verdict=="pass"` ∧ rights SHA 앵커 일치. 하나라도 미달 → **파일 미생성**.
- gate 기본 verdict = `unverified`(공개 차단). `gate_from_closure()` 신설 — rights graph closure 실측 결과에서 gate 조립(호출자 임의 dict 우회 축소).

## 2. 테스트

- `py_compile` 전건 OK / **Ran 67 tests / OK** (기존 53 → 67, 실패 0)
- 신규 회귀 **14건**: TestR1Regressions 13 + 실제 unknown 포함 강등 테스트 1
- misnamed `test_blocker_unknown_confirmed_downgrade_executes` → `test_confirmed_downgrade_executes`로 정정 + 진짜 unknown 포함판 신설 (감리 지시 3·4)
- demo_cycle: PASS

## 3. 감리 실측 결함 → 회귀 재현 결과

| 감리 실측 (구 구현) | R1 회귀 테스트 | 수정 후 |
|---|---|---|
| B3·breach 0·첫 훼손 → **B2 즉시 하강**(downgraded=false) | test_r1_first_breach_holds_stage | B3 유지·breach 1·강등 없음 |
| B2·A/B stale·breach 1 → **B1 강등** | test_r1_stale_freezes_stage_and_breach | B2·breach 동결·강등 없음 |
| unknown이 확인된 강등 차단 | test_r1_blocker_unknown_confirmed_downgrade_executes | fresh W회 확인 강등 실행 (B3→B2) |
| CASE3: confirmed + old streak → **active** | test_r1_spot_confirmed_with_old_streak_not_active | inactive |
| CASE4: approved + blocking_sources → **생성됨** | test_r1_approved_with_blocking_source_not_created | 미생성 (None, output 빈 목록) |

추가 대조: ceiling 하향 예외 유지(test_r1_ceiling_downward_still_allowed), B4 유지-관련 blocker unknown 동결 유지(test_r1_b4_maintenance_blocker_unknown_freezes), run 초기화·증가·동결(3건), blocking_tests·unverified verdict·실 closure gate 차단(3건).

## 4. 제출 정정 (감리 지적 반영)

- ZIP 항목 수 표현 정정: **엔트리 = 파일 + 디렉터리** (정확 수치는 이번 ZIP 목록 참조).
- **MANIFEST.md** 신설: 전 파일 relative_path | bytes | sha256 원장.

## 5. 백로그 (오픈 비차단 — 관제 등급 분류)

- shadow writer 권리 게이트(internal_shadow/derived_retention/decision_replay) — Shadow 착수 전 필수
- install_phase0.sh staging→rename 원자화
- spot_weakness anchor/run의 PersistentState 완전 편입 + late replay 재생
- promotion streak 동결 계약 단계별 확장 검증
- phase1_tech_probe.sh 실검증형 재작성(필드·이력·시점·WS sequence) — **Phase 1 실행 전 개정 필수, 엔진 보정과 별개 차수**
